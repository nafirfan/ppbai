import numpy as np
import json
import sys
from fuzzy_expert.variable import FuzzyVariable
from fuzzy_expert.rule import FuzzyRule
from fuzzy_expert.inference import DecompositionalInference

def fuz(json1, json2, json3):
    variables = {
        "nilaiRapor": FuzzyVariable(
            universe_range=(0, 100),
            terms={
                "TinggiR": [(70, 0), (80, 0.2), (90, 0.7), (100, 1)],
                "RendahR": [(0, 1), (30, 0.8), (40, 0.5), (50, 0.2), (70, 0)],
            },
        ),
        "nilaiPsikologi": FuzzyVariable(
            universe_range=(0, 100),
            terms={
                "TinggiP": [(70, 0), (80, 0.2), (90, 0.7), (100, 1)],
                "RendahP": [(0, 1), (40, 0.5), (50, 0.2), (70, 0)],
            },
        ),
        "nilaiToefl": FuzzyVariable(
            universe_range=(0, 100),
            terms={
                "TinggiT": [(70, 0), (80, 0.2), (90, 0.7), (100, 1)],
                "RendahT": [(0, 1), (30, 0.8), (40, 0.5), (50, 0.2), (70, 0)],
            },
        ),
        "decision": FuzzyVariable(
            universe_range=(0, 10),
            terms={
                "Seni": [(0, 1), (3, 1), (4, 0)],
                "Ekonomi": [(2, 0), (4, 1), (5,1), (7, 0)],
                "Teknik": [(7, 0), (9, 1), (10, 1)],
            },
        ),
    }

    rules = [
        FuzzyRule(
            premise=[
                ("nilaiRapor", "TinggiR"),
                ("AND", "nilaiPsikologi", "TinggiP"),
                ("AND", "nilaiToefl", "TinggiT"),
            ],
            consequence=[("decision", "Teknik")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "TinggiR"),
                ("AND", "nilaiPsikologi", "TinggiP"),
                ("AND", "nilaiToefl", "RendahT"),
            ],
            consequence=[("decision", "Teknik")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "TinggiR"),
                ("AND", "nilaiPsikologi", "RendahP"),
                ("AND", "nilaiToefl", "TinggiT"),
            ],
            consequence=[("decision", "Ekonomi")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "TinggiR"),
                ("AND", "nilaiPsikologi", "RendahP"),
                ("AND", "nilaiToefl", "RendahT"),
            ],
            consequence=[("decision", "Ekonomi")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "RendahR"),
                ("AND", "nilaiPsikologi", "TinggiP"),
                ("AND", "nilaiToefl", "TinggiT"),
            ],
            consequence=[("decision", "Teknik")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "RendahR"),
                ("AND", "nilaiPsikologi", "TinggiP"),
                ("AND", "nilaiToefl", "RendahT"),
            ],
            consequence=[("decision", "Seni")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "RendahR"),
                ("AND", "nilaiPsikologi", "RendahP"),
                ("AND", "nilaiToefl", "TinggiT"),
            ],
            consequence=[("decision", "Seni")],
        ),
        FuzzyRule(
            premise=[
                ("nilaiRapor", "RendahR"),
                ("AND", "nilaiPsikologi", "RendahP"),
                ("AND", "nilaiToefl", "RendahT"),
            ],
            consequence=[("decision", "Seni")],
        ),
    ]

    model = DecompositionalInference(
        and_operator="min",
        or_operator="max",
        implication_operator="Rc",
        composition_operator="max-min",
        production_link="max",
        defuzzification_operator="cog",
    )

    m = model(
        variables=variables,
        rules=rules,
        nilaiRapor=json1,
        nilaiPsikologi=json2,
        nilaiToefl=json3,
    )

    return m[0]['decision']

json1 = int(sys.argv[1])
json2 = int(sys.argv[2])
json3 = int(sys.argv[3])

sys.stdout.write(str(fuz(json1, json2, json3)))
sys.stdout.flush()
sys.exit(0)