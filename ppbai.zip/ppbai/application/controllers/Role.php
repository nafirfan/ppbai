<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelRole');
	}

	public function index() {
		$data['role'] = $this->ModelRole->getRole();
		$data['judul'] = 'Role';
		$data['halaman'] = 'admin/role';
		$this->load->view('admin/snippets/base', $data);
	}

	public function tambah() {
		$this->form_validation->set_rules('nama_role', 'Nama Role', 'trim|required|is_unique[role.namaRole]|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['judul'] = 'Tambah Role';
			$data['halaman'] = 'admin/roleTambah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$nama_role = $this->security->xss_clean(htmlspecialchars($this->input->post('nama_role', true)));
			$nextIdRole = $this->ModelRole->getIdRoleTerakhir();
			$data = [
				'idRole' => $nextIdRole['idRole'] + 1,
				'namaRole' => $nama_role,
				'dateCreated' => time(),
				'dateModified' => time(),
				'authorId' => $this->session->userdata('idUser'),
			];
			$data = $this->security->xss_clean($data);
			$this->ModelRole->insertRole($data);
			$this->session->set_flashdata('success', 'Role berhasil ditambahkan');
			redirect('admin/role', 'refresh');
		}
	}

	public function ubah() {
		$id_role = $this->uri->segment(4);
		$this->form_validation->set_rules('nama_role', 'Nama Role', 'trim|required|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['role'] = $this->ModelRole->getRoleById($id_role);
			$data['judul'] = 'Ubah Role';
			$data['halaman'] = 'admin/roleUbah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$nama_role = $this->security->xss_clean(htmlspecialchars($this->input->post('nama_role', true)));
			$data = [
				'namaRole' => $nama_role,
				'dateModified' => time(),
			];
			$data = $this->security->xss_clean($data);
			$this->ModelRole->updateRole($id_role, $data);
			$this->session->set_flashdata('success', 'Role berhasil diubah');
			redirect('admin/role', 'refresh');
		}
	}

	public function hapus() {
		$id_role = $this->uri->segment(4);
		$this->form_validation->set_rules('id_role', 'Kode Role', 'trim|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['role'] = $this->ModelRole->getRoleById($id_role);
			$data['judul'] = 'Hapus Role';
			$data['halaman'] = 'admin/roleHapus';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$this->ModelRole->deleteRole($id_role);
			$this->session->set_flashdata('success', 'Role berhasil dihapus');
			redirect('admin/role', 'refresh');
		}
	}
}