<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RiwayatLogin extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelRiwayatLogin');
	}

	public function index() {
		$idUser = $this->session->userdata('idUser');
		$data['riwayatLogin'] = $this->ModelRiwayatLogin->getRiwayatLoginById($idUser);
		$data['judul'] = 'Akun';
		$data['halaman'] = 'admin/riwayatLogin';
		$this->load->view('admin/snippets/base', $data);
	}
}