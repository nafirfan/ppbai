<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OrangTua extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelGuru');
		$this->load->model('ModelAkun');
		$this->load->model('ModelSiswa');
		$this->load->model('ModelOrangTua');
	}

	public function dashboard() {
		$data['akun'] = sizeof($this->ModelAkun->getAkun());
		$data['guru'] = sizeof($this->ModelGuru->getGuru());
		$data['siswa'] = sizeof($this->ModelSiswa->getSiswa());
		$data['ortu'] = sizeof($this->ModelOrangTua->getOrangTua());
		$data['judul'] = 'Dashboard';
		$data['halaman'] = 'admin/dashboard';
		$this->load->view('admin/snippets/base', $data);
	}
}