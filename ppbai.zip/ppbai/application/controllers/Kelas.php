<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelKelas');
		$this->load->model('ModelGuru');
	}

	public function index() {
		$data['kelas'] = $this->ModelKelas->getKelas();
		$data['judul'] = 'Kelas';
		$data['halaman'] = 'admin/kelas';
		$this->load->view('admin/snippets/base', $data);
	}

	public function tambah() {
		$this->form_validation->set_rules('namaKelas', 'Nama Kelas', 'trim|required|xss_clean');
		$this->form_validation->set_rules('waliKelas', 'Wali Kelas', 'trim|required|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['waliKelas'] = $this->ModelGuru->getGuru();
			$data['judul'] = 'Tambah Kelas';
			$data['halaman'] = 'admin/kelasTambah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$namaKelas = $this->security->xss_clean(htmlspecialchars($this->input->post('namaKelas', true)));
			$waliKelas = $this->security->xss_clean(htmlspecialchars($this->input->post('waliKelas', true)));
			$nextIdKelas = $this->ModelKelas->cekIdKelasTerakhir();

			$data = [
				'idkelas' => $nextIdKelas['idKelas'] + 1,
				'waliKelas' => $waliKelas,
				'namaKelas' => $namaKelas,
				'dateCreated' => time(),
				'dateModified' => time(),
				'authorId' => $this->session->userdata('idUser'),
			];
			$data = $this->security->xss_clean($data);
			$this->ModelKelas->insertKelas($data);
			$this->session->set_flashdata('success', 'Kelas berhasil ditambahkan');
			redirect('admin/kelas', 'refresh');
		}
	}

	public function ubah() {
		$idKelas = $this->uri->segment(4);
		$this->form_validation->set_rules('namaKelas', 'Nama kelas', 'trim|required|xss_clean');
		$this->form_validation->set_rules('waliKelas', 'Wali Kelas', 'trim|required|xss_clean');
		if ($this->form_validation->run() == false) {
			$idRole = 2;
			$data['waliKelas'] = $this->ModelGuru->getGuru();
			$data['kelas'] = $this->ModelKelas->getKelasById($idKelas);
			$data['judul'] = 'Ubah Kelas';
			$data['halaman'] = 'admin/kelasUbah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$namaKelas = $this->security->xss_clean(htmlspecialchars($this->input->post('namaKelas', true)));
			$waliKelas = $this->security->xss_clean(htmlspecialchars($this->input->post('waliKelas', true)));

			$data = [
				'namaKelas' => $namaKelas,
				'waliKelas' => $waliKelas,
				'dateModified' => time(),
			];
			$data = $this->security->xss_clean($data);
			$this->ModelKelas->updateKelas($idKelas, $data);
			$this->session->set_flashdata('success', 'Kelas berhasil diubah');
			redirect('admin/kelas', 'refresh');
		}
	}

	public function hapus() {
		$idKelas = $this->uri->segment(4);
		$this->form_validation->set_rules('idKelas', 'idKelas', 'trim|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['kelas'] = $this->ModelKelas->getKelasById($idKelas);
			$data['judul'] = 'Hapus Kelas';
			$data['halaman'] = 'admin/kelasHapus';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$this->ModelKelas->deleteKelas($idKelas);
			$this->session->set_flashdata('success', 'Kelas berhasil dihapus');
			redirect('admin/kelas', 'refresh');
		}
	}
}