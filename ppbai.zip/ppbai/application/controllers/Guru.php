<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'third_party/Spout/Autoloader/autoload.php';

use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;

class Guru extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelGuru');
		$this->load->model('ModelAkun');
		$this->load->model('ModelSiswa');
		$this->load->model('ModelOrangTua');
		$this->load->model('ModelKelas');
		$this->load->model('ModelDokumen');
		$this->load->model('ModelRekomendasi');
	}

	public function index() {
		$data['guru'] = $this->ModelGuru->getGuru();
		$data['judul'] = 'Guru';
		$data['halaman'] = 'admin/guru';
		$this->load->view('admin/snippets/base', $data);
	}

	public function dashboard() {
		$data['akun'] = sizeof($this->ModelAkun->getAkun());
		$data['guru'] = sizeof($this->ModelGuru->getGuru());
		$data['siswa'] = sizeof($this->ModelSiswa->getSiswa());
		$data['ortu'] = sizeof($this->ModelOrangTua->getOrangTua());
		$data['judul'] = 'Dashboard';
		$data['halaman'] = 'admin/dashboard';
		$this->load->view('admin/snippets/base', $data);
	}

	public function tambah() {
		$this->form_validation->set_rules('nama_guru', 'Nama Guru', 'trim|required|is_unique[guru.namaGuru]|xss_clean');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|is_unique[akun.username]|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['judul'] = 'Tambah Guru';
			$data['halaman'] = 'admin/guruTambah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$username = $this->security->xss_clean(htmlspecialchars($this->input->post('username', true)));
			$password = $this->security->xss_clean(htmlspecialchars($this->input->post('password', true)));
			$nama_guru = $this->security->xss_clean(htmlspecialchars($this->input->post('nama_guru', true)));
			$nextIdGuru = $this->ModelGuru->cekIdGuruTerakhir();
			$nextIdUser = $this->ModelAkun->cekIdAkunTerakhir();

			$dataGuru = [
				'idGuru' => $nextIdGuru['idGuru'] + 1,
				'namaGuru' => $nama_guru,
				'dateCreated' => time(),
				'dateModified' => time(),
				'authorId' => $this->session->userdata('idUser'),
				'idUser' => $nextIdUser['idUser'] + 1,
			];

			$dataAkun = [
				'idUser' => $nextIdUser['idUser'] + 1,
				'username' => $username,
				'password' => password_hash($password, PASSWORD_DEFAULT),
				'idRole' => 2,
				'dateCreated' => time(),
				'dateModified' => time(),
			];
			$dataAkun = $this->security->xss_clean($dataAkun);
			$dataGuru = $this->security->xss_clean($dataGuru);
			$this->ModelAkun->insertAkun($dataAkun);
			$this->ModelGuru->insertGuru($dataGuru);
			$this->session->set_flashdata('success', 'Guru berhasil ditambahkan');
			redirect('admin/guru', 'refresh');
		}
	}

	public function ubah() {
		$id_guru = $this->uri->segment(4);
		$id_user = $this->uri->segment(5);

		$this->form_validation->set_rules('nama_guru', 'Nama Guru', 'trim|xss_clean');
		$this->form_validation->set_rules('username', 'Username', 'trim|xss_clean');
		$this->form_validation->set_rules('password', 'New Password', 'trim|matches[password1]|xss_clean');
		$this->form_validation->set_rules('password1', 'Password Confirmation', 'trim|matches[password]|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['identitasAkun'] = $this->ModelGuru->getGuruById($id_guru);
			$data['judul'] = 'Ubah Guru';
			$data['halaman'] = 'admin/guruUbah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$nama_guru = $this->security->xss_clean(htmlspecialchars($this->input->post('nama_guru', true)));
			$password = $this->security->xss_clean(htmlspecialchars($this->input->post('password', true)));
			$password1 = $this->security->xss_clean(htmlspecialchars($this->input->post('password1', true)));

			if ($password != '' and $password1 != '') {
				$dataAkun = [
					'password' => password_hash($password, PASSWORD_DEFAULT),
					'dateModified' => time(),
				];
				$dataAkun = $this->security->xss_clean($dataAkun);
				$this->ModelAkun->updateAkun($id_user, $dataAkun);
			}

			if ($nama_guru != '') {
				$dataGuru = [
					'namaGuru' => $nama_guru,
					'dateModified' => time(),
				];
				$dataGuru = $this->security->xss_clean($dataGuru);
				$this->ModelGuru->updateGuru($id_guru, $dataGuru);
			}

			$this->session->set_flashdata('success', 'Guru berhasil diubah');
			redirect('admin/guru', 'refresh');
		}
	}

	public function hapus() {
		$id_guru = $this->uri->segment(4);
		$id_user = $this->uri->segment(5);

		$this->form_validation->set_rules('id_user', 'Kode User', 'trim|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['identitasAkun'] = $this->ModelGuru->getGuruById($id_guru);
			$data['judul'] = 'Hapus Guru';
			$data['halaman'] = 'admin/guruHapus';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$this->ModelGuru->deleteGuru($id_guru);
			$this->ModelAkun->deleteAkun($id_user);
			$this->session->set_flashdata('success', 'Guru berhasil dihapus');
			redirect('admin/guru', 'refresh');
		}
	}

	public function siswa() {
		$idUser = $this->session->userdata('idUser');
		$data['listSiswa'] = $this->ModelSiswa->getSiswaByWaliKelas($idUser);
		$data['judul'] = 'Siswa';
		$data['halaman'] = 'admin/siswa';
		$this->load->view('admin/snippets/base', $data);
	}

	public function tambahSiswa() {
		if ($this->input->method() === 'post') {
			$config['upload_path'] = './assets_admin/document/siswa/';
			$config['allowed_types'] = 'xlsx|xls';
			$config['max_size'] = '2048';
			$config['encrypt_name'] = true;
			$config['remove_spaces'] = true;
			$config['detect_mime'] = true;
			$config['mod_mime_fix'] = true;

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('file')) {
				$file = $this->upload->data();
				$reader = ReaderEntityFactory::createXLSXReader();
				$reader->open('assets_admin/document/siswa/' . $file['file_name']);
				foreach ($reader->getSheetIterator() as $sheet) {
					$numRow = 1;
					foreach ($sheet->getRowIterator() as $row) {
						if ($numRow > 1) {
							$nextIdUser = $this->ModelAkun->cekIdAkunTerakhir();
							$cekAkun = $this->ModelAkun->getAkunByUsername($row->getCellAtIndex(0));
							if (!$cekAkun) {
								$akunSiswa = array(
									'idUser' => $nextIdUser['idUser'] + 1,
									'username' => $row->getCellAtIndex(0), //nisn
									'password' => password_hash('siswa2023', PASSWORD_DEFAULT),
									'idRole' => 4,
									'dateCreated' => time(),
									'dateModified' => time(),
								);
								$akunOrtu = array(
									'idUser' => $nextIdUser['idUser'] + 2,
									'username' => 'ortu' . $row->getCellAtIndex(0), //ortunisn
									'password' => password_hash('ortu2023', PASSWORD_DEFAULT),
									'idRole' => 3,
									'dateCreated' => time(),
									'dateModified' => time(),
								);
								$cekKelas = $this->ModelKelas->getKelasByWaliKelas($this->session->userdata('idUser'));
								$dataSiswa = array(
									'nisn' => $row->getCellAtIndex(0),
									'nama' => $row->getCellAtIndex(1),
									'tempatLahir' => $row->getCellAtIndex(2),
									'tanggallahir' => $row->getCellAtIndex(3),
									'alamat' => $row->getCellAtIndex(4),
									'jenisKelamin' => $row->getCellAtIndex(5),
									'agama' => $row->getCellAtIndex(6),
									'foto' => '',
									'idKelas' => $cekKelas['idKelas'],
									'dateCreated' => time(),
									'dateModified' => time(),
									'waliKelas' => $this->session->userdata('idUser'),
									'idUser' => $nextIdUser['idUser'] + 1,
								);
								$nextIdOrtu = $this->ModelOrangTua->cekIdOrangTuaTerakhir();
								$dataOrtu = array(
									'idOrangTua' => $nextIdOrtu['idOrangTua'] + 1,
									'ayah' => $row->getCellAtIndex(7),
									'pekerjaanAyah' => $row->getCellAtIndex(8),
									'agamaAyah' => $row->getCellAtIndex(9),
									'ibu' => $row->getCellAtIndex(10),
									'pekerjaanIbu' => $row->getCellAtIndex(11),
									'agamaIbu' => $row->getCellAtIndex(12),
									'noTelp' => $row->getCellAtIndex(13),
									'alamat' => $row->getCellAtIndex(14),
									'dateCreated' => time(),
									'dateModified' => time(),
									'waliKelas' => $this->session->userdata('idUser'),
									'anak' => $row->getCellAtIndex(0),
									'idUser' => $nextIdUser['idUser'] + 2,
								);
								$this->ModelAkun->insertAkun($akunSiswa);
								$this->ModelAkun->insertAkun($akunOrtu);
								$this->ModelSiswa->insertSiswa($dataSiswa);
								$this->ModelOrangTua->insertOrangTua($dataOrtu);
							}
						}
						$numRow++;
					}
					$reader->close();
					unlink('assets_admin/document/siswa/' . $file['file_name']);
					$this->session->set_flashdata('success', 'Akun berhasil ditambahkan');
					redirect('guru/siswa', 'refresh');
				}
			} else {
				echo $this->upload->display_errors();
			}
		} else {
			$data['judul'] = 'Tambah Siswa';
			$data['halaman'] = 'admin/siswaTambah';
			$this->load->view('admin/snippets/base', $data);
		}
	}

	public function ubahSiswa() {
		$nisn = $this->uri->segment(4);
		$this->form_validation->set_rules('nama', 'Nama', 'trim|xss_clean');
		$this->form_validation->set_rules('jenisKelamin', 'Jenis Kelamin', 'trim|xss_clean');
		$this->form_validation->set_rules('agama', 'Agama', 'trim|xss_clean');
		$this->form_validation->set_rules('alamat', 'Alamat', 'trim|xss_clean');
		$this->form_validation->set_rules('tempatLahir', 'Tempat Lahir', 'trim|xss_clean');
		$this->form_validation->set_rules('tanggalLahir', 'Tanggal Lahir', 'trim|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['siswa'] = $this->ModelSiswa->getSiswaById($nisn);
			$data['judul'] = 'Ubah Siswa';
			$data['halaman'] = 'admin/siswaUbah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$nama = $this->security->xss_clean(htmlspecialchars($this->input->post('nama', true)));
			$jenisKelamin = $this->security->xss_clean(htmlspecialchars($this->input->post('jenisKelamin', true)));
			$agama = $this->security->xss_clean(htmlspecialchars($this->input->post('agama', true)));
			$alamat = $this->security->xss_clean(htmlspecialchars($this->input->post('alamat', true)));
			$tempatLahir = $this->security->xss_clean(htmlspecialchars($this->input->post('tempatLahir', true)));
			$tanggalLahir = $this->security->xss_clean(htmlspecialchars($this->input->post('tanggalLahir', true)));

			$data = [
				'nama' => $nama,
				'jenisKelamin' => $jenisKelamin,
				'agama' => $agama,
				'alamat' => $alamat,
				'tempatLahir' => $tempatLahir,
				'tanggalLahir' => $tanggalLahir,
				'dateModified' => time(),
			];
			$data = $this->security->xss_clean($data);
			$this->ModelSiswa->updateSiswa($nisn, $data);
			$this->session->set_flashdata('success', 'Siswa berhasil diubah');
			redirect('guru/siswa', 'refresh');
		}
	}

	public function ubahFotoSiswa() {
		$nisn = $this->uri->segment(4);
		$siswa = $this->ModelSiswa->getSiswaById($nisn);
		$config['upload_path'] = './assets_admin/images/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['max_size'] = '2048';
		$config['overwrite'] = true;
		$config['encrypt_name'] = true;
		$config['remove_spaces'] = true;
		$config['detect_mime'] = true;
		$config['mod_mime_fix'] = true;

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('foto')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			if ($siswa['foto'] != '') {
				unlink("./assets_admin/images/" . $siswa['foto']);
			}

			$file = $this->upload->data();
			$data = array(
				'foto' => $file['file_name'],
				'dateModified' => time(),
			);
			$data = $this->security->xss_clean($data);
			$this->ModelSiswa->updateSiswa($nisn, $data);
			$this->session->set_flashdata('success', 'Siswa berhasil diubah');
			redirect('guru/siswa', 'refresh');
		}
	}

	public function hapusSiswa() {
		$nisn = $this->uri->segment(4);
		$data['identitasAkun'] = $this->ModelSiswa->getSiswaById($nisn);

		$this->form_validation->set_rules('id_user', 'Kode User', 'trim|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['judul'] = 'Hapus Siswa';
			$data['halaman'] = 'admin/siswaHapus';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$idUser = $this->security->xss_clean(htmlspecialchars($this->input->post('id_user', true)));
			unlink("./assets_admin/images/" . $data['identitasAkun']['foto']);
			$this->ModelRekomendasi->deleteRekomendasi($data['identitasAkun']['idRekomendasi']);
			$this->ModelDokumen->deleteDokumen($data['identitasAkun']['idDokumen']);
			$this->ModelOrangTua->deleteOrangTua($data['identitasAkun']['idOrangTua']);
			$this->ModelSiswa->deleteSiswa($nisn);
			$this->ModelAkun->deleteAkun($idUser);
			$this->ModelAkun->deleteAkun($data['identitasAkun']['idUserOrtu']);
			$this->session->set_flashdata('success', 'Siswa berhasil dihapus');
			redirect('guru/siswa', 'refresh');
		}
	}

	public function unggahNilaiSiswa() {
		$nisn = $this->uri->segment(4);
		$data['siswa'] = $this->ModelDokumen->getDokumenByNISN($nisn);
		if (!$data['siswa']) {
			$data['siswa']['nilaiRapor'] = '';
			$data['siswa']['nilaiPsikologi'] = '';
			$data['siswa']['nilaiToefl'] = '';
		}
		$this->form_validation->set_rules('nilaiRapor', 'Nilai Rapor', 'trim|xss_clean');
		$this->form_validation->set_rules('nilaiPsikologi', 'Nilai Psikologi', 'trim|xss_clean');
		$this->form_validation->set_rules('nilaiToefl', 'Nilai Toefl', 'trim|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['judul'] = 'Unggah Nilai Siswa';
			$data['halaman'] = 'admin/siswaUnggah';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$nilaiRapor = $this->security->xss_clean(htmlspecialchars($this->input->post('nilaiRapor', true)));
			$nilaiPsikologi = $this->security->xss_clean(htmlspecialchars($this->input->post('nilaiPsikologi', true)));
			$nilaiToefl = $this->security->xss_clean(htmlspecialchars($this->input->post('nilaiToefl', true)));
			$nextIdDokumen = $this->ModelDokumen->cekIdDokumenTerakhir();
			$nextIdRekomendasi = $this->ModelRekomendasi->cekIdRekomendasiTerakhir();

			if ($data['siswa']['nilaiRapor'] != '') {
				$dataDokumen = [
					'nilaiRapor' => $nilaiRapor,
					'nilaiPsikologi' => $nilaiPsikologi,
					'nilaiToefl' => $nilaiToefl,
					'dateModified' => time(),
				];
				$dataDokumen = $this->security->xss_clean($dataDokumen);
				$this->ModelDokumen->updateDokumen($data['siswa']['idDokumen'], $dataDokumen);

				$o = null;
				$r = null;
				exec("python3 /Users/irfannafi/Sites/ppbai/fuzzy.py '$nilaiRapor' '$nilaiPsikologi' '$nilaiToefl'", $o, $r);
				$nilai = $o[0];

				$dataRekomendasi = [
					'dateCreated' => time(),
				];

				if ($nilai >= 0 && $nilai <= 3) {
					$dataRekomendasi['learningProfile'] = 'Kemampuan berpikir kritis dan analitis. Kemampuan mengekspresikan perasaan melalui seni. Kemampuan mengorganisir kegiatan seni rupa. Kemampuan menyajikan karya seni. Kemampuan bekerja secara individu dan tim. Kreatif dan Artistik';
					$dataRekomendasi['peminatan'] = 'Seni';
				} elseif ($nilai >= 4 && $nilai <= 6) {
					$dataRekomendasi['learningProfile'] = 'Tekun. Kritis. Observan. Berwawasan luas. Senang menganalisis. Senang melakukan riset. Keterampilan interpersonal. Senang memecahkan masalah';
					$dataRekomendasi['peminatan'] = 'Ekonomi';
				} elseif ($nilai >= 7 && $nilai <= 10) {
					$dataRekomendasi['learningProfile'] = 'Teliti. Tekun. Detil. Rasional. Terstruktur. Independen. Senang berhitung. Senang menganalisis. Senang bekerja sendiri. Senang melakukan riset. Senang memecahkan masalah';
					$dataRekomendasi['peminatan'] = 'Teknik';
				}
				$dataRekomendasi = $this->security->xss_clean($dataRekomendasi);
				$this->ModelRekomendasi->updateRekomendasi($data['siswa']['idRekomendasi'], $dataRekomendasi);

				$this->session->set_flashdata('success', 'Nilai siswa berhasil diubah');
			} else {
				$dataDokumen = [
					'idDokumen' => $nextIdDokumen['idDokumen'] + 1,
					'nilaiRapor' => $nilaiRapor,
					'nilaiPsikologi' => $nilaiPsikologi,
					'nilaiToefl' => $nilaiToefl,
					'siswa' => $nisn,
					'guru' => $this->session->userdata('idUser'),
					'dateModified' => time(),
					'dateCreated' => time(),
				];
				$dataDokumen = $this->security->xss_clean($dataDokumen);
				$this->ModelDokumen->insertDokumen($dataDokumen);

				$o = null;
				$r = null;
				exec("python3 /Users/irfannafi/Sites/ppbai/fuzzy.py '$nilaiRapor' '$nilaiPsikologi' '$nilaiToefl'", $o, $r);
				$nilai = $o[0];

				$dataRekomendasi = [
					'idRekomendasi' => $nextIdRekomendasi['idRekomendasi'] + 1,
					'dateCreated' => time(),
					'idDokumen' => $nextIdDokumen['idDokumen'] + 1,
					'siswa' => $nisn,
					'guru' => $this->session->userdata('idUser'),
				];

				if ($nilai >= 0 && $nilai <= 3) {
					$dataRekomendasi['learningProfile'] = 'Kemampuan berpikir kritis dan analitis. Kemampuan mengekspresikan perasaan melalui seni. Kemampuan mengorganisir kegiatan seni rupa. Kemampuan menyajikan karya seni. Kemampuan bekerja secara individu dan tim. Kreatif dan Artistik';
					$dataRekomendasi['peminatan'] = 'Seni';
				} elseif ($nilai >= 4 && $nilai <= 6) {
					$dataRekomendasi['learningProfile'] = 'Tekun. Kritis. Observan. Berwawasan luas. Senang menganalisis. Senang melakukan riset. Keterampilan interpersonal. Senang memecahkan masalah';
					$dataRekomendasi['peminatan'] = 'Ekonomi';
				} elseif ($nilai >= 7 && $nilai <= 10) {
					$dataRekomendasi['learningProfile'] = 'Teliti. Tekun. Detil. Rasional. Terstruktur. Independen. Senang berhitung. Senang menganalisis. Senang bekerja sendiri. Senang melakukan riset. Senang memecahkan masalah';
					$dataRekomendasi['peminatan'] = 'Teknik';
				}
				$dataRekomendasi = $this->security->xss_clean($dataRekomendasi);
				$this->ModelRekomendasi->insertRekomendasi($dataRekomendasi);
				$this->session->set_flashdata('success', 'Nilai siswa berhasil ditambah');
			}
			redirect('guru/siswa', 'refresh');
		}
	}
}