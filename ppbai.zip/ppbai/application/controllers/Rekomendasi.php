<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rekomendasi extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelRekomendasi');
	}

	public function index() {
		$id = $this->session->userdata('idUser');
		if ($this->session->userdata('role') == 'guru') {
			$data['rekomendasi'] = $this->ModelRekomendasi->getRekomendasiByGuru($id);
		} elseif ($this->session->userdata('role') == 'siswa') {
			$data['rekomendasi'] = $this->ModelRekomendasi->getRekomendasiBySiswa($id);
		} elseif ($this->session->userdata('role') == 'orangTua') {
			$data['rekomendasi'] = $this->ModelRekomendasi->getRekomendasiByOrangTua($id);
		}

		$data['judul'] = 'Rekomendasi';
		$data['halaman'] = 'admin/rekomendasi';
		$this->load->view('admin/snippets/base', $data);
	}
}