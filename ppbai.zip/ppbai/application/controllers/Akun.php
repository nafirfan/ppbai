<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Akun extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('ModelAkun');
		$this->load->model('ModelGuru');
		$this->load->model('ModelSiswa');
		$this->load->model('ModelOrangTua');
		$this->load->model('ModelRiwayatLogin');
		$this->load->library('user_agent');
	}

	public function index() {
		$data['judul'] = 'Dashboard';
		$data['halaman'] = 'admin/dashboard';
		$this->load->view('admin/snippets/base', $data);
	}

	public function dashboard() {
		$data['akun'] = sizeof($this->ModelAkun->getAkun());
		$data['guru'] = sizeof($this->ModelGuru->getGuru());
		$data['siswa'] = sizeof($this->ModelSiswa->getSiswa());
		$data['ortu'] = sizeof($this->ModelOrangTua->getOrangTua());
		$data['judul'] = 'Dashboard';
		$data['halaman'] = 'admin/dashboard';
		$this->load->view('admin/snippets/base', $data);
	}

	public function login() {
		$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

		if ($this->form_validation->run() == true) {
			$username = $this->security->xss_clean(htmlspecialchars($this->input->post('username', true)));
			$password = $this->security->xss_clean(htmlspecialchars($this->input->post('password', true)));

			if ($this->agent->is_browser()) {
				$agent = $this->agent->browser() . ' ' . $this->agent->version();
			} elseif ($this->agent->is_mobile()) {
				$agent = $this->agent->mobile();
			} elseif ($this->agent->is_robot()) {
				$agent = $this->agent->robot();
			} else {
				$agent = 'Unidentified User Agent';
			}

			$user = $this->ModelAkun->getAkunByUsername($username);

			if ($user) {
				if (password_verify($password, $user['password'])) {
					if ($user['idRole'] == 1) {
						$role = 'admin';
					} elseif ($user['idRole'] == 2) {
						$role = 'guru';
					} elseif ($user['idRole'] == 3) {
						$role = 'orangTua';
					} elseif ($user['idRole'] == 4) {
						$role = 'siswa';
					}
					$data = [
						'idUser' => $user['idUser'],
						'username' => $user['username'],
						'idRole' => $user['idRole'],
						'role' => $role,
					];
					$this->session->set_userdata($data);

					$dataAgent = array(
						'ipAddress' => $this->input->ip_address(),
						'browser' => $agent,
						'sisOperasi' => $this->agent->platform(),
						'dateCreated' => time(),
						'authorId' => $user['idUser'],
					);
					$dataAgent = $this->security->xss_clean($dataAgent);
					$this->ModelRiwayatLogin->insertRiwayatLogin($dataAgent);
					if ($user['idRole'] == 1) {
						redirect('admin/dashboard', 'refresh');
					} elseif ($user['idRole'] == 2) {
						redirect('guru/dashboard', 'refresh');
					} elseif ($user['idRole'] == 3) {
						redirect('orangTua/dashboard', 'refresh');
					} elseif ($user['idRole'] == 4) {
						redirect('siswa/dashboard', 'refresh');
					}
				} else {
					$this->session->set_flashdata('danger', 'Password salah');
					redirect('login', 'refresh');
				}
			} else {
				$this->session->set_flashdata('danger', 'Username tidak terdaftar');
				redirect('login', 'refresh');
			}
		} else {
			$this->load->view('admin/login');
		}
	}

	public function logout() {
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('idRole');
		$this->session->unset_userdata('idUser');
		$this->session->unset_userdata('role');
		$this->session->sess_destroy();
		$this->session->set_flashdata('message', 'Anda sudah logout');
		redirect('login', 'refresh');
	}

	public function ubahPassword() {
		$idUser = $this->session->userdata('idUser');
		$role = $this->session->userdata('role');
		$this->form_validation->set_rules('newPassword', 'New Password', 'trim|required|min_length[6]|matches[confirmPassword]|xss_clean');
		$this->form_validation->set_rules('confirmPassword', 'Password Confirmation', 'trim|required|min_length[6]|matches[newPassword]|xss_clean');
		if ($this->form_validation->run() == false) {
			$data['identitasAkun'] = $this->ModelAkun->getAkunById($idUser);
			$data['judul'] = 'Akun';
			$data['halaman'] = 'admin/ubahPassword';
			$this->load->view('admin/snippets/base', $data);
		} else {
			$password = password_hash(htmlspecialchars($this->input->post('newPassword', true)), PASSWORD_DEFAULT);
			$data = [
				'password' => $password,
				'dateModified' => time(),
			];
			$this->ModelAkun->updateAkun($idUser, $data);
			$this->session->set_flashdata('success', 'Password berhasil dirubah');
			redirect($role . '/ubahPassword', 'refresh');
		}
	}

	public function ubahProfil() {
		$role = $this->session->userdata('role');
		$idUser = $this->session->userdata('idUser');

		if ($role == 'guru') {
			$this->form_validation->set_rules('nama', 'Nama Guru', 'trim|xss_clean');
			$data['identitasAkun'] = $this->ModelAkun->getAkunById($idUser);
			if ($this->form_validation->run() == false) {
				$data['halaman'] = 'admin/ubahProfilGuru';
			} else {
				$nama_guru = $this->security->xss_clean(htmlspecialchars($this->input->post('nama', true)));
				$dataGuru = [
					'namaGuru' => $nama_guru,
					'dateModified' => time(),
				];
				$dataGuru = $this->security->xss_clean($dataGuru);
				$this->ModelGuru->updateGuru($data['identitasAkun']['idGuru'], $dataGuru);
				$this->session->set_flashdata('success', 'Profil berhasil dirubah');
				redirect($role . '/ubahProfil', 'refresh');
			}

		} elseif ($role == 'orangTua') {
			$this->form_validation->set_rules('namaAyah', 'Nama Ayah', 'trim|xss_clean');
			$this->form_validation->set_rules('pekerjaanAyah', 'Pekerjaan Ayah', 'trim|xss_clean');
			$this->form_validation->set_rules('agamaAyah', 'Agama Ayah', 'trim|xss_clean');
			$this->form_validation->set_rules('namaIbu', 'Nama Ibu', 'trim|xss_clean');
			$this->form_validation->set_rules('pekerjaanIbu', 'Pekerjaan Ibu', 'trim|xss_clean');
			$this->form_validation->set_rules('agamaIbu', 'Agama Ibu', 'trim|xss_clean');
			$this->form_validation->set_rules('alamat', 'Alamat', 'trim|xss_clean');
			$this->form_validation->set_rules('noTelp', 'No Telp', 'trim|xss_clean');
			$data['ortu'] = $this->ModelAkun->getAkunById($idUser);
			if ($this->form_validation->run() == false) {
				$data['halaman'] = 'admin/ubahProfilOrangTua';
			} else {
				$namaAyah = $this->security->xss_clean(htmlspecialchars($this->input->post('namaAyah', true)));
				$pekerjaanAyah = $this->security->xss_clean(htmlspecialchars($this->input->post('pekerjaanAyah', true)));
				$agamaAyah = $this->security->xss_clean(htmlspecialchars($this->input->post('agamaAyah', true)));
				$namaIbu = $this->security->xss_clean(htmlspecialchars($this->input->post('namaIbu', true)));
				$pekerjaanIbu = $this->security->xss_clean(htmlspecialchars($this->input->post('pekerjaanIbu', true)));
				$agamaIbu = $this->security->xss_clean(htmlspecialchars($this->input->post('agamaIbu', true)));
				$alamat = $this->security->xss_clean(htmlspecialchars($this->input->post('alamat', true)));
				$noTelp = $this->security->xss_clean(htmlspecialchars($this->input->post('noTelp', true)));

				$dataOrtu = [
					'ayah' => $namaAyah,
					'pekerjaanAyah' => $pekerjaanAyah,
					'agamaAyah' => $agamaAyah,
					'ibu' => $namaIbu,
					'pekerjaanIbu' => $pekerjaanIbu,
					'agamaIbu' => $agamaIbu,
					'alamat' => $alamat,
					'noTelp' => $noTelp,
					'dateModified' => time(),
				];
				$dataOrtu = $this->security->xss_clean($dataOrtu);
				$this->ModelOrangTua->updateOrangTua($data['ortu']['idOrangTua'], $dataOrtu);
				$this->session->set_flashdata('success', 'Profil berhasil diubah');
				redirect($role . '/ubahProfil', 'refresh');
			}

		} elseif ($role == 'siswa') {
			$this->form_validation->set_rules('nama', 'Nama', 'trim|xss_clean');
			$this->form_validation->set_rules('jenisKelamin', 'Jenis Kelamin', 'trim|xss_clean');
			$this->form_validation->set_rules('agama', 'Agama', 'trim|xss_clean');
			$this->form_validation->set_rules('alamat', 'Alamat', 'trim|xss_clean');
			$this->form_validation->set_rules('tempatLahir', 'Tempat Lahir', 'trim|xss_clean');
			$this->form_validation->set_rules('tanggalLahir', 'Tanggal Lahir', 'trim|xss_clean');
			$data['siswa'] = $this->ModelAkun->getAkunById($idUser);
			if ($this->form_validation->run() == false) {
				$data['halaman'] = 'admin/ubahProfilSiswa';
			} else {
				$nama = $this->security->xss_clean(htmlspecialchars($this->input->post('nama', true)));
				$jenisKelamin = $this->security->xss_clean(htmlspecialchars($this->input->post('jenisKelamin', true)));
				$agama = $this->security->xss_clean(htmlspecialchars($this->input->post('agama', true)));
				$alamat = $this->security->xss_clean(htmlspecialchars($this->input->post('alamat', true)));
				$tempatLahir = $this->security->xss_clean(htmlspecialchars($this->input->post('tempatLahir', true)));
				$tanggalLahir = $this->security->xss_clean(htmlspecialchars($this->input->post('tanggalLahir', true)));

				$dataSiswa = [
					'nama' => $nama,
					'jenisKelamin' => $jenisKelamin,
					'agama' => $agama,
					'alamat' => $alamat,
					'tempatLahir' => $tempatLahir,
					'tanggalLahir' => $tanggalLahir,
					'dateModified' => time(),
				];
				$dataSiswa = $this->security->xss_clean($dataSiswa);
				$this->ModelSiswa->updateSiswa($data['siswa']['nisn'], $dataSiswa);
				$this->session->set_flashdata('success', 'Profil berhasil diubah');
				redirect($role . '/ubahProfil', 'refresh');
			}

		}
		$data['judul'] = 'Akun';
		$this->load->view('admin/snippets/base', $data);
	}

	public function ubahFoto() {
		$role = $this->session->userdata('role');
		$idUser = $this->session->userdata('idUser');
		$nisn = $this->uri->segment(3);
		$siswa = $this->ModelSiswa->getSiswaById($nisn);
		$config['upload_path'] = './assets_admin/images/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['max_size'] = '2048';
		$config['overwrite'] = true;
		$config['encrypt_name'] = true;
		$config['remove_spaces'] = true;
		$config['detect_mime'] = true;
		$config['mod_mime_fix'] = true;

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('foto')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			if ($siswa['foto'] != '') {
				unlink("./assets_admin/images/" . $siswa['foto']);
			}

			$file = $this->upload->data();
			$data = array(
				'foto' => $file['file_name'],
				'dateModified' => time(),
			);
			$data = $this->security->xss_clean($data);
			$this->ModelSiswa->updateSiswa($nisn, $data);
			$this->session->set_flashdata('success', 'Profil berhasil diubah');
			redirect($role . '/ubahProfil', 'refresh');
		}
	}
}