<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'akun/login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login'] = 'Akun/login';
$route['logout'] = 'Akun/logout';

$route['admin'] = 'Akun/index';
$route['admin/dashboard'] = 'Akun/dashboard';

$route['admin/role'] = 'Role/index';
$route['admin/role/tambah'] = 'Role/tambah';
$route['admin/role/ubah/(:any)'] = 'Role/ubah';
$route['admin/role/hapus/(:any)'] = 'Role/hapus';
$route['admin/guru'] = 'Guru/index';
$route['admin/guru/tambah'] = 'Guru/tambah';
$route['admin/guru/ubah/(:any)/(:any)'] = 'Guru/ubah';
$route['admin/guru/hapus/(:any)/(:any)'] = 'Guru/hapus';
$route['admin/kelas'] = 'Kelas/index';
$route['admin/kelas/tambah'] = 'Kelas/tambah';
$route['admin/kelas/ubah/(:any)'] = 'Kelas/ubah';
$route['admin/kelas/hapus/(:any)'] = 'Kelas/hapus';

$route['guru'] = 'Guru/index';
$route['guru/dashboard'] = 'Guru/dashboard';
$route['guru/siswa'] = 'Guru/siswa';
$route['guru/siswa/tambah'] = 'Guru/tambahSiswa';
$route['guru/siswa/ubah/(:any)'] = 'Guru/ubahSiswa';
$route['guru/siswa/ubahFoto/(:any)'] = 'Guru/ubahFotoSiswa';
$route['guru/siswa/hapus/(:any)'] = 'Guru/hapusSiswa';
$route['guru/siswa/unggah/(:any)'] = 'Guru/unggahNilaiSiswa';

$route['orangTua'] = 'OrangTua/index';
$route['orangTua/dashboard'] = 'OrangTua/dashboard';

$route['siswa'] = 'Siswa/index';
$route['siswa/dashboard'] = 'Siswa/dashboard';

$route['(:any)/riwayatLogin'] = 'RiwayatLogin/index';
$route['(:any)/ubahPassword'] = 'Akun/ubahPassword';
$route['(:any)/ubahProfil'] = 'Akun/ubahProfil';
$route['(:any)/ubahProfil/(:any)'] = 'Akun/ubahProfil';
$route['(:any)/ubahFoto/(:any)'] = 'Akun/ubahFoto';
$route['(:any)/hasilRekomendasi'] = 'Rekomendasi/index';