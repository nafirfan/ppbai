<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelDokumen extends CI_Model {
	public function getDokumen() {
		return $this->db->get('dokumen')->result_array();
	}

	public function getDokumenById($id) {
		$this->db->where('idDokumen', $id);
		return $this->db->get('dokumen')->row_array();
	}

	public function getDokumenByNISN($id) {
		$this->db->join('rekomendasi', 'rekomendasi.idDokumen = dokumen.idDokumen', 'left');
		$this->db->where('dokumen.siswa', $id);
		return $this->db->get('dokumen')->row_array();
	}

	public function cekIdDokumenTerakhir() {
		$this->db->select('idDokumen');
		$this->db->order_by('idDokumen', 'desc');
		$this->db->limit(1);
		return $this->db->get('dokumen')->row_array();
	}

	public function insertDokumen($data) {
		return $this->db->insert('dokumen', $data);
	}

	public function updateDokumen($id, $data) {
		$this->db->set($data);
		$this->db->where('idDokumen', $id);
		return $this->db->update('dokumen');
	}

	public function deleteDokumen($id) {
		$this->db->where('idDokumen', $id);
		return $this->db->delete('dokumen');
	}
}

/* End of file ModelDokumen.php */
/* Location: ./application/models/ModelDokumen.php */