<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelRiwayatLogin extends CI_Model {

	public function getRiwayatLoginById($id) {
		$this->db->where('authorId', $id);
		return $this->db->get('riwayatLogin')->result_array();
	}

	public function insertRiwayatLogin($data) {
		return $this->db->insert('riwayatLogin', $data);
	}

}

/* End of file ModelRiwayatLogin.php */
/* Location: ./application/models/ModelRiwayatLogin.php */