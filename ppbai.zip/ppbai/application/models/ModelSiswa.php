<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelSiswa extends CI_Model {
	public function getSiswa() {
		return $this->db->get('siswa')->result_array();
	}

	public function getSiswaById($id) {
		$this->db->select('nisn, foto, jenisKelamin, nama, siswa.alamat, agama, tanggalLahir, tempatLahir, siswa.idUser, idOrangTua, orangTua.idUser AS idUserOrtu, dokumen.idDokumen, rekomendasi.idRekomendasi');
		$this->db->join('dokumen', 'dokumen.siswa = siswa.nisn', 'left');
		$this->db->join('rekomendasi', 'rekomendasi.idDokumen = dokumen.idDokumen', 'left');
		$this->db->join('orangTua', 'orangTua.anak = siswa.nisn', 'left');
		$this->db->where('nisn', $id);
		return $this->db->get('siswa')->row_array();
	}

	public function getSiswaByWaliKelas($id) {
		$this->db->join('kelas', 'kelas.waliKelas = siswa.waliKelas', 'left');
		$this->db->where('siswa.waliKelas', $id);
		return $this->db->get('siswa')->result_array();
	}

	public function insertSiswa($data) {
		return $this->db->insert('siswa', $data);
	}

	public function updateSiswa($id, $data) {
		$this->db->set($data);
		$this->db->where('nisn', $id);
		return $this->db->update('siswa');
	}

	public function deleteSiswa($id) {
		$this->db->where('nisn', $id);
		return $this->db->delete('siswa');
	}
}

/* End of file ModelSiswa.php */
/* Location: ./application/models/ModelSiswa.php */