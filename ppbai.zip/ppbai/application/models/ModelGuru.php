<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelGuru extends CI_Model {

	public function getGuru() {
		$this->db->join('akun', 'akun.idUser = guru.idUser', 'left');
		return $this->db->get('guru')->result_array();
	}

	public function getGuruById($id) {
		$this->db->join('kelas', 'kelas.waliKelas = guru.idUser', 'left');
		$this->db->join('akun', 'akun.idUser = guru.idUser', 'left');
		$this->db->where('idGuru', $id);
		return $this->db->get('guru')->row_array();
	}

	public function cekIdGuruTerakhir() {
		$this->db->select('idGuru');
		$this->db->order_by('idGuru', 'desc');
		$this->db->limit(1);
		return $this->db->get('guru')->row_array();
	}

	public function insertGuru($data) {
		return $this->db->insert('guru', $data);
	}

	public function updateGuru($id, $data) {
		$this->db->set($data);
		$this->db->where('idGuru', $id);
		return $this->db->update('guru');
	}

	public function deleteGuru($id) {
		$this->db->where('idGuru', $id);
		return $this->db->delete('guru');
	}

}

/* End of file ModelGuru.php */
/* Location: ./application/models/ModelGuru.php */