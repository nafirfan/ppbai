<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelRole extends CI_Model {
	public function getRole() {
		return $this->db->get('role')->result_array();
	}

	public function getRoleById($id) {
		$this->db->where('idRole', $id);
		return $this->db->get('role')->row_array();
	}

	public function getIdRoleTerakhir() {
		$this->db->select('idRole');
		$this->db->order_by('idRole', 'desc');
		$this->db->limit(1);
		return $this->db->get('role')->row_array();
	}

	public function insertRole($data) {
		return $this->db->insert('role', $data);
	}

	public function updateRole($id, $data) {
		$this->db->set($data);
		$this->db->where('idRole', $id);
		return $this->db->update('role');
	}

	public function deleteRole($id) {
		$this->db->where('idRole', $id);
		return $this->db->delete('role');
	}
}

/* End of file ModelRole.php */
/* Location: ./application/models/ModelRole.php */