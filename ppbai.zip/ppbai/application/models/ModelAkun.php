<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelAkun extends CI_Model {

	public function getAkun() {
		return $this->db->get('akun')->result_array();
	}

	public function getAkunById($id) {
		$this->db->select('*, orangTua.alamat as alamatOrtu');
		$this->db->join('orangTua', 'orangTua.idUser = akun.iduser', 'left');
		$this->db->join('siswa', 'siswa.idUser = akun.idUser', 'left');
		$this->db->join('guru', 'guru.idUser = akun.idUser', 'left');
		$this->db->join('role', 'role.idROle = akun.idRole', 'left');
		$this->db->where('akun.idUser', $id);
		return $this->db->get('akun')->row_array();
	}

	public function cekIdAkunTerakhir() {
		$this->db->select('idUser');
		$this->db->order_by('idUser', 'desc');
		$this->db->limit(1);
		return $this->db->get('akun')->row_array();
	}

	public function getAkunByUsername($username) {
		$this->db->where('username', $username);
		return $this->db->get('akun')->row_array();
	}

	public function insertAkun($data) {
		return $this->db->insert('akun', $data);
	}

	public function updateAkun($id, $data) {
		$this->db->set($data);
		$this->db->where('idUser', $id);
		return $this->db->update('akun');
	}

	public function deleteAkun($id) {
		$this->db->where('idUser', $id);
		return $this->db->delete('akun');
	}
}

/* End of file ModelAkun.php */
/* Location: ./application/models/ModelAkun.php */