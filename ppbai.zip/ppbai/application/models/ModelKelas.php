<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelKelas extends CI_Model {

	public function getKelas() {
		$this->db->join('akun', 'akun.idUser = kelas.waliKelas', 'left');
		$this->db->join('guru', 'guru.idGuru = kelas.waliKelas', 'left');
		return $this->db->get('kelas')->result_array();
	}

	public function getKelasById($id) {
		$this->db->where('idKelas', $id);
		return $this->db->get('kelas')->row_array();
	}

	public function getKelasByWaliKelas($id) {
		$this->db->where('waliKelas', $id);
		return $this->db->get('kelas')->row_array();
	}

	public function cekIdKelasTerakhir() {
		$this->db->select('idKelas');
		$this->db->order_by('idKelas', 'desc');
		$this->db->limit(1);
		return $this->db->get('kelas')->row_array();
	}

	public function insertKelas($data) {
		return $this->db->insert('kelas', $data);
	}

	public function updateKelas($id, $data) {
		$this->db->set($data);
		$this->db->where('idKelas', $id);
		return $this->db->update('kelas');
	}

	public function deleteKelas($id) {
		$this->db->where('idKelas', $id);
		return $this->db->delete('kelas');
	}
}

/* End of file Modelkelas.php */
/* Location: ./application/models/Modelkelas.php */