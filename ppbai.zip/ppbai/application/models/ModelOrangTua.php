<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelOrangTua extends CI_Model {
	public function getOrangTua() {
		return $this->db->get('orangTua')->result_array();
	}

	public function getOrangTuaById($id) {
		$this->db->where('idOrangTua', $id);
		return $this->db->get('orangTua');
	}

	public function cekIdOrangTuaTerakhir() {
		$this->db->select('idOrangTua');
		$this->db->order_by('idOrangTua', 'desc');
		$this->db->limit(1);
		return $this->db->get('orangTua')->row_array();
	}

	public function insertOrangTua($data) {
		return $this->db->insert('orangTua', $data);
	}

	public function updateOrangTua($id, $data) {
		$this->db->set($data);
		$this->db->where('idOrangTua', $id);
		return $this->db->update('orangTua');
	}

	public function deleteOrangTua($id) {
		$this->db->where('idOrangTua', $id);
		return $this->db->delete('orangTua');
	}
}

/* End of file ModelOrangTua.php */
/* Location: ./application/models/ModelOrangTua.php */