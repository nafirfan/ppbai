<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelRekomendasi extends CI_Model {
	public function getRekomendasi() {
		return $this->db->get('rekomendasi')->result_array();
	}

	public function getRekomendasiById($id) {
		$this->db->where('idRekomendasi', $id);
		return $this->db->get('rekomendasi')->row_array();
	}

	public function getRekomendasiByGuru($id) {
		$this->db->join('siswa', 'siswa.nisn = rekomendasi.siswa', 'left');
		$this->db->where('guru', $id);
		return $this->db->get('rekomendasi')->result_array();
	}

	public function getRekomendasiBySiswa($id) {
		$this->db->join('siswa', 'siswa.nisn = rekomendasi.siswa', 'left');
		$this->db->where('siswa.idUser', $id);
		return $this->db->get('rekomendasi')->row_array();
	}

	public function getRekomendasiByOrangTua($id) {
		$this->db->join('siswa', 'siswa.nisn = rekomendasi.siswa', 'left');
		$this->db->join('orangTua', 'orangTua.anak = siswa.nisn', 'left');
		$this->db->where('orangTua.idUser', $id);
		return $this->db->get('rekomendasi')->row_array();
	}

	public function cekIdRekomendasiTerakhir() {
		$this->db->select('idRekomendasi');
		$this->db->order_by('idRekomendasi', 'desc');
		$this->db->limit(1);
		return $this->db->get('rekomendasi')->row_array();
	}

	public function insertRekomendasi($data) {
		return $this->db->insert('rekomendasi', $data);
	}

	public function updateRekomendasi($id, $data) {
		$this->db->set($data);
		$this->db->where('idRekomendasi', $id);
		return $this->db->update('rekomendasi');
	}

	public function deleteRekomendasi($id) {
		$this->db->where('idRekomendasi', $id);
		return $this->db->delete('rekomendasi');
	}
}

/* End of file ModelRekomendasi.php */
/* Location: ./application/models/ModelRekomendasi.php */