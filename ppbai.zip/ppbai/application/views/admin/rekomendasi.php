<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Akun</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item active">Akun</li>
              <li class="breadcrumb-item active" aria-current="page">Rekomendasi</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <!-- Table -->
  <div class="row">
    <div class="col">
      <div class="card">
        <!-- Card header -->
        <div class="card-header">
          <div class="row align-items-center">
            <!-- Title -->
            <div class="col-8">
              <h5 class="h3 mb-0">Rekomendasi</h5>
            </div>
            <div class="col-4 text-right">
            </div>
          </div>
        </div>
        <div class="table-responsive py-4">
          <table class="table table-flush" id="tabelRekomendasi">
            <thead class="thead-light">
              <tr>
                <th>Nama Siswa</th>
                <th>Learning Profile</th>
                <th>Peminatan</th>
                <th>Dibuat</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php if ($this->session->userdata('role') == 'guru'): ?>
                <?php foreach ($rekomendasi as $key): ?>
                  <tr>
                    <td><?=$key['nama']?></td>
                    <td class="text-wrap"><?=$key['learningProfile']?></td>
                    <td><?=$key['peminatan']?></td>
                    <td><?=date('d M Y', html_escape($key['dateCreated']))?></td>
                  </tr>
                <?php endforeach?>
              <?php elseif ($this->session->userdata('role') == 'siswa' || $this->session->userdata('role') == 'orangTua'): ?>
              <tr>
                <td><?=$rekomendasi['nama']?></td>
                <td class="text-wrap"><?=$rekomendasi['learningProfile']?></td>
                <td><?=$rekomendasi['peminatan']?></td>
                <td><?=date('d M Y', html_escape($rekomendasi['dateCreated']))?></td>
              </tr>
            <?php endif?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- Footer -->
<?php include 'snippets/footer.php';?>
</div>