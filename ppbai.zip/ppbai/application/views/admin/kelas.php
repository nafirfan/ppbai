<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Admin</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item active">Admin</li>
              <li class="breadcrumb-item active" aria-current="page">Kelas</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <!-- Table -->
  <div class="row">
    <div class="col">
      <div class="card">
        <!-- Card header -->
        <div class="card-header">
          <div class="row align-items-center">
            <!-- Title -->
            <div class="col-8">
              <h5 class="h3 mb-0">Kelas</h5>
            </div>
            <div class="col-4 text-right">
              <a class="btn btn-sm btn-primary seeLatestLogin text-white" href="<?=base_url()?>admin/kelas/tambah">Tambah Kelas</a>
            </div>
          </div>
        </div>
        <div class="table-responsive py-4">
          <table class="table table-flush" id="datatableManageAccounts">
            <thead class="thead-light">
              <tr>
                <th>Nama Kelas</th>
                <th>Wali Kelas</th>
                <th>Dibuat</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($kelas as $key): ?>
                <tr>
                  <td><?=html_escape($key['namaKelas'])?></td>
                  <td><?=html_escape($key['username'])?></td>
                  <td><?=date('d M Y', html_escape($key['dateCreated']))?></td>
                  <td class="text-center">
                    <div class="dropdown">
                      <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-v"></i>
                      </a>
                      <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                        <a class="dropdown-item" href="<?=base_url();?>admin/kelas/ubah/<?=html_escape($key['idKelas'])?>">Ubah</a>
                        <a class="dropdown-item" href="<?=base_url();?>admin/kelas/hapus/<?=html_escape($key['idKelas'])?>">Hapus</a>
                      </div>
                    </div>
                  </td>
                </tr>
              <?php endforeach?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <?php include 'snippets/footer.php';?>
</div>