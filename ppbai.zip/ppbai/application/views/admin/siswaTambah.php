<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Admin</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a>Admin</a></li>
              <li class="breadcrumb-item active" aria-current="page">Tambah Siswa</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <div class="row">
    <div class="col-7">
      <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
          <h3 class="mb-0">Tambah Siswa</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
          <!-- Form groups used in grid -->
          <form action="<?=base_url()?>guru/siswa/tambah" method="post" enctype="multipart/form-data">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label class="form-control-label" for="form-file">Unggah excel*</label>
                  <input type="file" class="form-control" id="form-file" name="file" placeholder="file" required="" accept=".xlsx,.xls">
                  <?=form_error('file', '<small class="text-red">', '</small>')?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <a class="btn btn-info" href="<?=base_url()?>guru/siswa">Batal</a>
                <button class="btn btn-primary" type="submit" name="submit">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="col-5">
      <div class="card">
        <div class="card-header">
          <h3 class="mb-0">Panduan</h3>
        </div>
        <div class="card-body">
          <ul>
            <li>Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Explicabo, sit pariatur, quo, quia eligendi quasi nostrum quis commodi vel omnis fugiat quas sequi corrupti? Dolorem cupiditate vero distinctio, delectus at.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <?php include 'snippets/footer.php';?>
</div>