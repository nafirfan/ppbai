<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Admin</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a>Admin</a></li>
              <li class="breadcrumb-item active" aria-current="page">Ubah Kelas</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <div class="card mb-4">
    <!-- Card header -->
    <div class="card-header">
      <h3 class="mb-0">Ubah Kelas</h3>
    </div>
    <!-- Card body -->
    <div class="card-body">
      <!-- Form groups used in grid -->
      <form action="<?=base_url()?>admin/kelas/ubah/<?=html_escape($kelas['idKelas'])?>" method="post">
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label class="form-control-label" for="form-namaKelas">Nama Kelas*</label>
              <input type="text" class="form-control" id="form-namaKelas" name="namaKelas" placeholder="Nama Kelas" required="" value="<?=html_escape($kelas['namaKelas'])?>">
              <?=form_error('namaKelas', '<small class="text-red">', '</small>')?>
            </div>
            <div class="form-group">
              <label class="form-control-label" for="form-waliKelas">Wali Kelas*</label>
              <select class="form-control" id="form-waliKelas" name="waliKelas" required="">
                <?php foreach ($waliKelas as $key) {
	if ($key['idUser'] == $kelas['waliKelas']) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	?>
                <option <?=$selected?> value="<?=html_escape($key['idUser'])?>"><?=html_escape($key['namaGuru'])?></option>
              <?php }?>
            </select>
            <?=form_error('waliKelas', '<small class="text-red">', '</small>')?>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <a class="btn btn-info" href="<?=base_url()?>admin/kelas">Batal</a>
          <button class="btn btn-primary" type="submit">Submit</button>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Footer -->
<?php include 'snippets/footer.php';?>
</div>