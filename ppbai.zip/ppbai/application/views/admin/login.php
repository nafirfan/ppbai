  <!DOCTYPE html>
  <html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="Creative Tim">
    <title>ADMIN - LOGIN</title>
    <!-- Favicon -->
    <link rel="icon" href="<?=base_url()?>assets_admin/img/brand/favicon.png" type="image/png">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <!-- Icons -->
    <link rel="stylesheet" href="<?=base_url()?>assets_admin/vendor/nucleo/css/nucleo.css" type="text/css">
    <link rel="stylesheet" href="<?=base_url()?>assets_admin/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
    <!-- Argon CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets_admin/vendor/animate.css/animate.min.css">
    <link rel="stylesheet" href="<?=base_url()?>assets_admin/css/argon.css?v=1.1.0" type="text/css">
  </head>

  <body class="bg-default">
    <!-- Main content -->
    <div class="main-content">
      <!-- Header -->
      <div class="header bg-gradient-primary py-7 py-lg-8 pt-lg-9">
        <div class="separator separator-bottom separator-skew zindex-100">
          <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
            <polygon class="fill-default" points="2560 0 2560 100 0 100"></polygon>
          </svg>
        </div>
      </div>
      <!-- Page content -->
      <div class="container mt--8 pb-5">
        <div class="row justify-content-center">
          <div class="col-lg-5 col-md-7">
            <div class="card bg-secondary border-0 mb-0">
              <div class="card-body px-lg-5 py-lg-5">
                <div class="text-center text-muted mb-4">
                </div>
                <form method="post" action="<?=base_url()?>login">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                  <div class="form-group mb-3">
                    <div class="input-group input-group-merge input-group-alternative">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                      </div>
                      <input class="form-control" placeholder="Username" type="text" name="username" value="<?=set_value('username')?>" required="" autocomplete="off">
                      <?=form_error('username', '<small class="text-red">', '</small>')?>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                      </div>
                      <input class="form-control" placeholder="Password" type="password" name="password" required="" autocomplete="off">
                      <?=form_error('password', '<small class="text-red">', '</small>')?>
                    </div>
                  </div>
                  <div class="text-center">
                    <a class="btn btn-info" href="<?=base_url()?>">Kembali</a>
                    <button type="submit" class="btn btn-primary my-4" id="btnLogin">Masuk</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer -->
    <footer class="py-5" id="footer-main">
      <div class="container">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-12">
            <div class="copyright text-center text-muted">
              &copy; 2021 <a class="font-weight-bold ml-1">IN</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Argon Scripts -->
    <!-- Core -->
    <script src="<?=base_url()?>assets_admin/vendor/jquery/dist/jquery.min.js"></script>
    <script src="<?=base_url()?>assets_admin/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url()?>assets_admin/vendor/js-cookie/js.cookie.js"></script>
    <script src="<?=base_url()?>assets_admin/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
    <script src="<?=base_url()?>assets_admin/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
    <script src="<?=base_url()?>assets_admin/vendor/bootstrap-notify/bootstrap-notify.min.js"></script>
    <!-- Argon JS -->
    <script src="<?=base_url()?>assets_admin/js/argon.js?v=1.1.0"></script>
    <!-- Demo JS - remove this in your project -->
    <script src="<?=base_url()?>assets_admin/js/demo.min.js"></script>
  </body>

  <script type="text/javascript">
    <?php if ($this->session->flashdata('danger')) {?>
      $.notify({
        icon: 'ni ni-notification-70',
        title: ' Warning',
        message: '<?=$this->session->flashdata('danger')?>',
        url: ''
      }, {
        element: 'body',
        type: 'danger',
        allow_dismiss: true,
        placement: {
          from: 'top',
          align: 'center'
        },
        offset: {
        x: 15, // Keep this as default
        y: 15 // Unless there'll be alignment issues as this value is targeted in CSS
      },
      spacing: 10,
      z_index: 1080,
      delay: 2500,
      timer: 25000,
      url_target: '_blank',
      mouse_over: false,
      animate: {
        // enter: animIn,
        // exit: animOut
        enter: "animated fadeInUp",
        exit: "animated fadeOutDown"
      },
      template: '<div data-notify="container" class="alert alert-dismissible alert-{0} alert-notify" role="alert">' +
      '<span class="alert-icon" data-notify="icon"></span> ' +
      '<div class="alert-text"</div> ' +
      '<span class="alert-title" data-notify="title">{1}</span> ' +
      '<span data-notify="message">{2}</span>' +
      '</div>' +
        // '<div class="progress" data-notify="progressbar">' +
        // '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
        // '</div>' +
        // '<a href="{3}" target="{4}" data-notify="url"></a>' +
      '<button type="button" class="close" data-notify="dismiss" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
      '</div>'
    });
    <?php }?>
  </script>

  </html>