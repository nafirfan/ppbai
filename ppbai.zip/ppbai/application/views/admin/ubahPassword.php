<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Akun</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a>Akun</a></li>
              <li class="breadcrumb-item active" aria-current="page">Ubah Password</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <div class="row">
    <div class="col-xl-4 order-xl-2">
      <div class="card card-profile">
        <img src="<?=base_url()?>assets_admin/img/theme/img-1-1000x600.jpg" alt="Image placeholder" class="card-img-top">
        <div class="row justify-content-center">
          <div class="col-lg-3 order-lg-2">
            <div class="card-profile-image">
              <a>
                <img src="<?=base_url()?>assets_admin/img/theme/default.png" class="rounded-circle">
              </a>
            </div>
          </div>
        </div>
        <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
        </div>
        <div class="card-body pt-0">
          <div class="row">
            <div class="col">
              <div class="card-profile-stats d-flex justify-content-center">
              </div>
            </div>
          </div>
          <div class="text-center">
            <h5 class="h3">
              <?=html_escape($identitasAkun['username'])?>
              <br>
              <span class="font-weight-light">
                <?php if ($identitasAkun['idRole'] == 1) {?>
                  <span class="badge badge-default"><?=html_escape($identitasAkun['namaRole'])?></span>
                <?php } else {?>
                  <span class="badge badge-warning"><?=html_escape($identitasAkun['namaRole'])?></span>
                <?php }?>
              </span>
            </h5>
            <div class="h5 font-weight-300">
              <i class="ni location_pin mr-2"></i>Since, <?=date('d M Y', html_escape($identitasAkun['dateCreated']))?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-8 order-xl-1">
      <div class="card">
        <div class="card-header">
          <div class="row align-items-center">
            <div class="col-8">
              <h3 class="mb-0">Ubah Password </h3>
            </div>
          </div>
        </div>
        <div class="card-body">
          <form method="post" action="<?=base_url()?><?=$this->session->userdata('role')?>/ubahPassword">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label" for="newPassword">Password Baru*</label>
                  <input type="password" id="newPassword" name="newPassword" class="form-control" placeholder="Password Baru" required="">
                  <?=form_error('newPassword', '<small class="text-red">', '</small>')?>
                </div>
                <div class="form-group">
                  <label class="form-control-label" for="confirmPassword">Konfirmasi Password*</label>
                  <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" placeholder="Konfirmasi Password" required="">
                  <?=form_error('confirmPassword', '<small class="text-red">', '</small>')?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <?php include 'snippets/footer.php';?>
</div>