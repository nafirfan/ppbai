<footer class="footer pt-0">
  <div class="row align-items-center justify-content-lg-between">
    <div class="col-lg-12">
      <!-- <div class="copyright text-center text-muted">
        &copy; 2021 <a class="font-weight-bold ml-1">IN</a>
    </div> -->
    </div>
  </div>
</footer>