<script src="<?=base_url()?>assets_admin/vendor/jquery/dist/jquery.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/js-cookie/js.cookie.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
<!-- notif -->
<script src="<?=base_url()?>assets_admin/vendor/bootstrap-notify/bootstrap-notify.min.js"></script>
<!-- datatable -->
<script src="<?=base_url()?>assets_admin/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="<?=base_url()?>assets_admin/vendor/image-cropper/cropper.js"></script>
<!-- Argon JS -->
<script src="<?=base_url()?>assets_admin/js/argon.js?v=1.1.0"></script>

<script type="text/javascript">
    function message(title, message, type) {
        $.notify({
            icon: 'ni ni-notification-70',
            title: title,
            message: message,
            url: ''
        },
        {
            element: 'body',
            type: type,
            allow_dismiss: true,
            placement: {
                from: 'top',
                align: 'center'
            },
            offset: {
                x: 15,
                y: 15
            },
            spacing: 10,
            z_index: 1080,
            delay: 2500,
            timer: 2500,
            url_target: '_blank',
            mouse_over: false,
            animate: {
                enter: "animated fadeInUp",
                exit: "animated fadeOutDown"
            },
            template: '<div data-notify="container" class="alert alert-dismissible alert-{0} alert-notify" role="alert">' +
            '<span class="alert-icon" data-notify="icon"></span> ' +
            '<div class="alert-text"</div> ' +
            '<span class="alert-title" data-notify="title">{1}</span> ' +
            '<span data-notify="message">{2}</span>' +
            '</div>' +
            '<button type="button" class="close" data-notify="dismiss" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
            '</div>'
        });
    }
</script>

<?php
if ($this->session->flashdata('success')) {
	$title = 'Success';
	$type = 'success';
	$message = $this->session->flashdata('success');
	echo "<script type='text/javascript'>message('$title', '$message', '$type')</script>";
} elseif ($this->session->flashdata('warning')) {
	$title = 'Warning';
	$type = 'warning';
	$message = $this->session->flashdata('warning');
	echo "<script type='text/javascript'>message('$title', '$message', '$type')</script>";

}?>