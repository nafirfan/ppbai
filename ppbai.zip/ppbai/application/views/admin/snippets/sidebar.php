<nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
  <div class="scrollbar-inner">
    <!-- Brand -->
    <div class="sidenav-header d-flex align-items-center">
      <a class="navbar-brand" href="<?=base_url();?>dashboard">
        <h3 class="heading-title text-primary">PPBAI</h3>
      </a>
      <div class="ml-auto">
        <!-- Sidenav toggler -->
        <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin" data-target="#sidenav-main">
          <div class="sidenav-toggler-inner">
            <i class="sidenav-toggler-line"></i>
            <i class="sidenav-toggler-line"></i>
            <i class="sidenav-toggler-line"></i>
          </div>
        </div>
      </div>
    </div>
    <div class="navbar-inner">
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Nav items -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link <?=($this->uri->segment(2) == 'dashboard') ? 'active' : '';?>" href="<?=base_url()?><?=$this->session->userdata('role')?>/dashboard">
              <i class="ni ni-world-2 text-primary"></i>
              <span class="nav-link-text">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <?php
$uri2 = ['ubahPassword', 'riwayatLogin', 'ubahProfil', 'hasilRekomendasi'];
if (in_array($this->uri->segment(2), $uri2)) {
	$navLink = 'active';
	$ariaExpanded = 'true';
	$collapse = 'show';
} else {
	$navLink = '';
	$ariaExpanded = 'false';
	$collapse = '';
}
?>
           <a class="nav-link <?=$navLink?>" href="#navbar-akun" data-toggle="collapse" role="button" aria-expanded="<?=$ariaExpanded?>" aria-controls="navbar-akun">
            <i class="ni ni-circle-08 text-info"></i>
            <span class="nav-link-text">Akun</span>
          </a>
          <div class="collapse <?=$collapse?>" id="navbar-akun">
            <ul class="nav nav-sm flex-column">
              <?php if ($this->session->userdata('role') != 'admin'): ?>
                <li class="nav-item">
                  <a href="<?=base_url()?><?=$this->session->userdata('role')?>/ubahProfil" class="nav-link <?=($this->uri->segment(2) == 'ubahProfil') ? 'active' : '';?>">Ubah Profil</a>
                </li>
              <?php endif?>
              <li class="nav-item">
                <a href="<?=base_url()?><?=$this->session->userdata('role')?>/ubahPassword" class="nav-link <?=($this->uri->segment(2) == 'ubahPassword') ? 'active' : '';?>">Ubah Password</a>
              </li>
              <li class="nav-item">
                <a href="<?=base_url()?><?=$this->session->userdata('role')?>/riwayatLogin" class="nav-link <?=($this->uri->segment(2) == 'riwayatLogin') ? 'active' : '';?>">Riwayat Login</a>
              </li>
              <?php if ($this->session->userdata('role') != 'admin'): ?>
                <li class="nav-item">
                  <a href="<?=base_url()?><?=$this->session->userdata('role')?>/hasilRekomendasi" class="nav-link <?=($this->uri->segment(2) == 'hasilRekomendasi') ? 'active' : '';?>">Hasil Rekomendasi</a>
                </li>
              <?php endif?>
            </ul>
          </div>
        </li>
        <?php if ($this->session->userdata('role') == 'admin'): ?>
          <li class="nav-item">
            <?php
$uri2 = ['role', 'guru', 'kelas'];
if (in_array($this->uri->segment(2), $uri2)) {
	$navLink = 'active';
	$ariaExpanded = 'true';
	$collapse = 'show';
} else {
	$navLink = '';
	$ariaExpanded = 'false';
	$collapse = '';
}
?>
           <a class="nav-link <?=$navLink?>" href="#navbar-admin" data-toggle="collapse" role="button" aria-expanded="<?=$ariaExpanded?>" aria-controls="navbar-admin">
            <i class="ni ni-user-run text-green"></i>
            <span class="nav-link-text">Admin</span>
          </a>
          <div class="collapse <?=$collapse?>" id="navbar-admin">
            <ul class="nav nav-sm flex-column">
              <li class="nav-item">
                <a href="<?=base_url()?>admin/role" class="nav-link <?=($this->uri->segment(2) == 'role') ? 'active' : '';?>">Manajemen Role</a>
              </li>
              <li class="nav-item">
                <a href="<?=base_url()?>admin/guru" class="nav-link <?=($this->uri->segment(2) == 'guru') ? 'active' : '';?>">Manajemen Guru</a>
              </li>
              <li class="nav-item">
                <a href="<?=base_url()?>admin/kelas" class="nav-link <?=($this->uri->segment(2) == 'kelas') ? 'active' : '';?>">Manajemen Kelas</a>
              </li>
            </ul>
          </div>
        </li>
      <?php endif?>
      <?php if ($this->session->userdata('role') == 'guru'): ?>
        <li class="nav-item">
          <?php
if ($this->uri->segment(2) == 'siswa') {
	$navLink = 'active';
	$ariaExpanded = 'true';
	$collapse = 'show';
} else {
	$navLink = '';
	$ariaExpanded = 'false';
	$collapse = '';
}
?>
         <a class="nav-link <?=$navLink?>" href="#navbar-guru" data-toggle="collapse" role="button" aria-expanded="<?=$ariaExpanded?>" aria-controls="navbar-guru">
          <i class="ni ni-spaceship text-yellow"></i>
          <span class="nav-link-text">Guru</span>
        </a>
        <div class="collapse <?=$collapse?>" id="navbar-guru">
          <ul class="nav nav-sm flex-column">
            <li class="nav-item">
              <a href="<?=base_url()?>guru/siswa" class="nav-link <?=($this->uri->segment(2) == 'siswa') ? 'active' : '';?>">Manajemen Siswa</a>
            </li>
          </ul>
        </div>
      </li>
    <?php endif?>
  </ul>
</div>
</div>
</div>
</nav>