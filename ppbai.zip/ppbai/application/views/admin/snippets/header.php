<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
<meta name="author" content="Creative Tim">
<title>ADMIN - <?= html_escape($judul) ?></title>
<!-- Favicon -->
<link rel="icon" href="<?= base_url() ?>assets_admin/img/brand/favicon.png" type="image/png">
<!-- Fonts -->
<link rel="icon" href="<?= base_url(); ?>assets/images/icon.ico" type="image/x-icon"/>
<!-- Icons -->
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/nucleo/css/nucleo.css" type="text/css">
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/animate.css/animate.min.css">
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css">
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/vendor/image-cropper/image-cropper.css">
<!-- Argon CSS -->
<link rel="stylesheet" href="<?= base_url() ?>assets_admin/css/argon.css?v=1.1.0" type="text/css">