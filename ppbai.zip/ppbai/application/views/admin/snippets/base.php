<!DOCTYPE html>
<html>

<head>
  <?php include 'header.php'; ?>
</head>

<body>
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topbar -->
    <?php include 'topbar.php'; ?>
    <?php $this->load->view($halaman); ?>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <?php include 'script.php'; ?>
</body>

</html>