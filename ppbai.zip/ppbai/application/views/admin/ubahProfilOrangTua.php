<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Orang Tua</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a>Akun</a></li>
              <li class="breadcrumb-item active" aria-current="page">Ubah Profil</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <div class="row">
    <div class="col-xl-12 order-xl-1">
      <div class="card">
        <div class="card-header">
          <div class="row align-items-center">
            <div class="col-8">
              <h3 class="mb-0">Ubah Profil Orang Tua</h3>
            </div>
          </div>
        </div>
        <div class="card-body">
          <form method="post" action="<?=base_url()?>orangTua/ubahProfil/<?=$ortu['idGuru']?>">
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label" for="input-namaAyah">Nama Ayah</label>
                  <input type="text" id="input-namaAyah" name="namaAyah" class="form-control" placeholder="Nama Ayah" value="<?=$ortu['ayah']?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="input-pekerjaanAyah">Pekerjaan Ayah</label>
                  <input type="text" id="input-pekerjaanAyah" name="pekerjaanAyah" class="form-control" placeholder="Pekerjaan Ayah" value="<?=$ortu['pekerjaanAyah']?>">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="agamaAyah">Agama Ayah</label>
                  <select class="form-control" id="agamaAyah" name="agamaAyah">
                    <option value="Islam" <?=($ortu['agamaAyah'] == 'Islam') ? 'selected' : '';?>>Islam</option>
                    <option value="Kristen" <?=($ortu['agamaAyah'] == 'Kristen') ? 'selected' : '';?>>Kristen</option>
                    <option value="Katolik" <?=($ortu['agamaAyah'] == 'Katolik') ? 'selected' : '';?>>Katolik</option>
                    <option value="Hindu" <?=($ortu['agamaAyah'] == 'Hindu') ? 'selected' : '';?>>Hindu</option>
                    <option value="Budha" <?=($ortu['agamaAyah'] == 'Budha') ? 'selected' : '';?>>Budha</option>
                    <option value="Konghucu" <?=($ortu['agamaAyah'] == 'Konghucu') ? 'selected' : '';?>>Konghucu</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label" for="input-namaIbu">Nama Ibu</label>
                  <input type="text" id="input-namaIbu" name="namaIbu" class="form-control" placeholder="Nama Ibu" value="<?=$ortu['ibu']?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="input-pekerjaanIbu">Pekerjaan Ibu</label>
                  <input type="text" id="input-pekerjaanIbu" name="pekerjaanIbu" class="form-control" placeholder="pekerjaanIbu" value="<?=$ortu['pekerjaanIbu']?>">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="agamaIbu">Agama Ibu</label>
                  <select class="form-control" id="agamaIbu" name="agamaIbu">
                    <option value="Islam" <?=($ortu['agamaIbu'] == 'Islam') ? 'selected' : '';?>>Islam</option>
                    <option value="Kristen" <?=($ortu['agamaIbu'] == 'Kristen') ? 'selected' : '';?>>Kristen</option>
                    <option value="Katolik" <?=($ortu['agamaIbu'] == 'Katolik') ? 'selected' : '';?>>Katolik</option>
                    <option value="Hindu" <?=($ortu['agamaIbu'] == 'Hindu') ? 'selected' : '';?>>Hindu</option>
                    <option value="Budha" <?=($ortu['agamaIbu'] == 'Budha') ? 'selected' : '';?>>Budha</option>
                    <option value="Konghucu" <?=($ortu['agamaIbu'] == 'Konghucu') ? 'selected' : '';?>>Konghucu</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="input-alamat">Alamat</label>
                  <input id="input-alamat" class="form-control" placeholder="Alamat" value="<?=$ortu['alamatOrtu']?>" type="text" name="alamat">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="input-noTelp">No Telp</label>
                  <input id="input-noTelp" class="form-control" placeholder="No Telp" value="<?=$ortu['noTelp']?>" type="text" name="noTelp">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <?php include 'snippets/footer.php'?>
</div>