<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Akun</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a>Akun</a></li>
              <li class="breadcrumb-item active" aria-current="page">Riwayat Login</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <!-- Table -->
  <div class="row">
    <div class="col">
      <div class="card">
        <!-- Card header -->
        <div class="card-header">
          <div class="row align-items-center">
            <!-- Title -->
            <div class="col-8">
              <h5 class="h3 mb-0">Riwayat Login</h5>
            </div>
            <div class="col-4 text-right">
            </div>
          </div>
        </div>
        <div class="table-responsive py-4">
          <table class="table table-flush" id="datatableManageAccounts">
            <thead class="thead-light">
              <tr>
                <th>IP Address</th>
                <th>Browser</th>
                <th>Sistem Operasi</th>
                <th>Waktu</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($riwayatLogin as $key): ?>
                <tr>
                  <td><?= html_escape($key['ipAddress']) ?></td>
                  <td><?= html_escape($key['browser']) ?></td>
                  <td><?= html_escape($key['sisOperasi']) ?></td>
                  <td><?= date('d M Y', html_escape($key['dateCreated'])) ?></td>
                </tr>
              <?php endforeach ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <?php include 'snippets/footer.php'; ?>
</div>