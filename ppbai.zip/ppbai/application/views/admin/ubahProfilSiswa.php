<!-- Header -->
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Siswa</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a>Akun</a></li>
              <li class="breadcrumb-item active" aria-current="page">Ubah Profil</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <div class="row">
    <div class="col-xl-4 order-xl-2">
      <div class="card card-profile">
        <img src="<?=base_url()?>assets_admin/img/theme/img-1-1000x600.jpg" alt="Image placeholder" class="card-img-top">
        <div class="row justify-content-center">
          <div class="col-lg-3 order-lg-2">
            <div class="card-profile-image">
              <a href="#">
                <?php if ($siswa['foto'] == '') {?>
                  <img src="<?=base_url()?>assets_admin/img/theme/default.png" class="rounded-circle">
                <?php } else {?>
                  <img src="<?=base_url()?>assets_admin/images/<?=$siswa['foto']?>" class="rounded-circle">
                <?php }?>
              </a>
            </div>
          </div>
        </div>
        <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
          <div class="d-flex justify-content-between">
          </div>
        </div>
        <div class="card-body pt-0">
          <div class="row">
            <div class="col">
              <div class="card-profile-stats d-flex justify-content-center">
              </div>
            </div>
          </div>
          <div class="text-center">
            <form method="post" action="<?=base_url()?>siswa/ubahFoto/<?=$siswa['nisn']?>" enctype="multipart/form-data">
              <div class="row custom-file">
                <input type="file" class="custom-file-input" id="customFileLang" lang="en" name="foto">
                <label class="custom-file-label" for="customFileLang">Select file</label>
              </div>
              <div class="">
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-8 order-xl-1">
      <div class="card">
        <div class="card-header">
          <div class="row align-items-center">
            <div class="col-8">
              <h3 class="mb-0">Ubah Profil Siswa </h3>
            </div>
          </div>
        </div>
        <div class="card-body">
          <form method="post" action="<?=base_url()?>siswa/ubahProfil/<?=$siswa['nisn']?>">
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label" for="input-nama">Nama</label>
                  <input type="text" id="input-nama" name="nama" class="form-control" placeholder="Nama" value="<?=$siswa['nama']?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="jenisKelamin">Jenis Kelamin</label>
                  <select class="form-control" id="jenisKelamin" name="jenisKelamin">
                    <option value="Wanita" <?=($siswa['jenisKelamin'] == 'Wanita') ? 'selected' : '';?> >Wanita</option>
                    <option value="Pria" <?=($siswa['jenisKelamin'] == 'Pria') ? 'selected' : '';?>>Pria</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="agama">Agama</label>
                  <select class="form-control" id="agama" name="agama">
                    <option value="Islam" <?=($siswa['agama'] == 'Islam') ? 'selected' : '';?>>Islam</option>
                    <option value="Kristen" <?=($siswa['agama'] == 'Kristen') ? 'selected' : '';?>>Kristen</option>
                    <option value="Katolik" <?=($siswa['agama'] == 'Katolik') ? 'selected' : '';?>>Katolik</option>
                    <option value="Hindu" <?=($siswa['agama'] == 'Hindu') ? 'selected' : '';?>>Hindu</option>
                    <option value="Budha" <?=($siswa['agama'] == 'Budha') ? 'selected' : '';?>>Budha</option>
                    <option value="Konghucu" <?=($siswa['agama'] == 'Konghucu') ? 'selected' : '';?>>Konghucu</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label" for="input-alamat">Alamat</label>
                  <input id="input-alamat" class="form-control" placeholder="Alamat" value="<?=$siswa['alamat']?>" type="text" name="alamat">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="input-tempatLahir">Tempat Lahir</label>
                  <input type="text" id="input-tempatLahir" class="form-control" placeholder="Tempat Lahir" value="<?=$siswa['tempatLahir']?>" name="tempatLahir">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label" for="input-tanggalLahir">Tanggal Lahir</label>
                  <input class="form-control" type="date" value="<?=$siswa['tanggalLahir']?>" id="input-tanggalLahir" name="tanggalLahir">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <?php include 'snippets/footer.php'?>
</div>