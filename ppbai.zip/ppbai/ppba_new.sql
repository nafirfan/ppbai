/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 101002
 Source Host           : localhost:3306
 Source Schema         : ppba_new

 Target Server Type    : MySQL
 Target Server Version : 101002
 File Encoding         : 65001

 Date: 09/01/2023 21:35:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for akun
-- ----------------------------
DROP TABLE IF EXISTS `akun`;
CREATE TABLE `akun` (
  `idUser` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `idRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`idUser`),
  KEY `idRole` (`idRole`),
  CONSTRAINT `akun_ibfk_1` FOREIGN KEY (`idRole`) REFERENCES `role` (`idRole`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of akun
-- ----------------------------
BEGIN;
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (1, 'irfannafi', '$2y$10$YKDrBvC4XQq89.UtZG9eJO/YXgCWXlnjuyedRSwicgVkfONqzEXxe', 1622049141, 1622049141, 1);
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (2, 'nafi', '$2y$10$jxmG2DsVXp5C5Sv.DDgcB.CvMxRbcrK0GYQ0AQNyLmVOOWBLp2N.W', 1673261094, 1673261094, 2);
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (3, 'irfan', '$2y$10$395eEKdoV/PaZ35CvW9XMOUusoxRZdLRc7wZRdQt2j99CbF.d92h6', 1673261143, 1673261143, 2);
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (4, '1301202164', '$2y$10$PEHz3rvvVht6RCu18Gjh2e8BlHpqHfbT6omKawbEzu.HDEGNApaN2', 1673261275, 1673261275, 4);
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (5, 'ortu1301202164', '$2y$10$LK6MveSNkiuHtyh.HOpKwOMXMlI1RSvbG7xD64OZCxDgfLsWMiIby', 1673261275, 1673261275, 3);
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (6, '1301202165', '$2y$10$PyXVjcMlRGD7cWhOHIE7tejAYb7MGpzLnkfrBHJMPJhxLlcdf2ji.', 1673267042, 1673267042, 4);
INSERT INTO `akun` (`idUser`, `username`, `password`, `dateCreated`, `dateModified`, `idRole`) VALUES (7, 'ortu1301202165', '$2y$10$dtBH3DFtRZAuDBtvrXz.kezWaIU7Kgh80w4xgUgGCNjGTVYCK7F7e', 1673267042, 1673267042, 3);
COMMIT;

-- ----------------------------
-- Table structure for dokumen
-- ----------------------------
DROP TABLE IF EXISTS `dokumen`;
CREATE TABLE `dokumen` (
  `idDokumen` int(11) NOT NULL AUTO_INCREMENT,
  `nilaiRapor` int(11) DEFAULT NULL,
  `nilaiPsikologi` int(11) DEFAULT NULL,
  `nilaiToefl` int(11) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `siswa` varchar(10) DEFAULT NULL,
  `guru` int(11) DEFAULT NULL,
  PRIMARY KEY (`idDokumen`),
  KEY `siswa` (`siswa`),
  CONSTRAINT `dokumen_ibfk_1` FOREIGN KEY (`siswa`) REFERENCES `siswa` (`nisn`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of dokumen
-- ----------------------------
BEGIN;
INSERT INTO `dokumen` (`idDokumen`, `nilaiRapor`, `nilaiPsikologi`, `nilaiToefl`, `dateCreated`, `dateModified`, `siswa`, `guru`) VALUES (1, 80, 80, 80, 1673261319, 1673272268, '1301202164', 2);
INSERT INTO `dokumen` (`idDokumen`, `nilaiRapor`, `nilaiPsikologi`, `nilaiToefl`, `dateCreated`, `dateModified`, `siswa`, `guru`) VALUES (2, 50, 50, 50, 1673267100, 1673273581, '1301202165', 2);
COMMIT;

-- ----------------------------
-- Table structure for guru
-- ----------------------------
DROP TABLE IF EXISTS `guru`;
CREATE TABLE `guru` (
  `idGuru` int(11) NOT NULL AUTO_INCREMENT,
  `namaGuru` varchar(40) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  `idUser` int(11) DEFAULT NULL,
  PRIMARY KEY (`idGuru`),
  KEY `authorId` (`authorId`),
  KEY `idUser` (`idUser`),
  CONSTRAINT `guru_ibfk_1` FOREIGN KEY (`authorId`) REFERENCES `akun` (`idUser`),
  CONSTRAINT `guru_ibfk_2` FOREIGN KEY (`idUser`) REFERENCES `akun` (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of guru
-- ----------------------------
BEGIN;
INSERT INTO `guru` (`idGuru`, `namaGuru`, `dateCreated`, `dateModified`, `authorId`, `idUser`) VALUES (1, 'nafi', 1673261094, 1673261094, 1, 2);
INSERT INTO `guru` (`idGuru`, `namaGuru`, `dateCreated`, `dateModified`, `authorId`, `idUser`) VALUES (2, 'irfan', 1673261143, 1673261143, 1, 3);
COMMIT;

-- ----------------------------
-- Table structure for kelas
-- ----------------------------
DROP TABLE IF EXISTS `kelas`;
CREATE TABLE `kelas` (
  `idKelas` int(11) NOT NULL AUTO_INCREMENT,
  `namaKelas` varchar(10) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `waliKelas` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  PRIMARY KEY (`idKelas`),
  KEY `waliKelas` (`waliKelas`),
  KEY `authorId` (`authorId`),
  CONSTRAINT `kelas_ibfk_1` FOREIGN KEY (`waliKelas`) REFERENCES `akun` (`idUser`),
  CONSTRAINT `kelas_ibfk_2` FOREIGN KEY (`authorId`) REFERENCES `akun` (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of kelas
-- ----------------------------
BEGIN;
INSERT INTO `kelas` (`idKelas`, `namaKelas`, `dateCreated`, `dateModified`, `waliKelas`, `authorId`) VALUES (1, 'XII-RPL-5', 1673261133, 1673262224, 2, 1);
INSERT INTO `kelas` (`idKelas`, `namaKelas`, `dateCreated`, `dateModified`, `waliKelas`, `authorId`) VALUES (2, 'XII-RPL-3', 1673262245, 1673262245, 3, 1);
COMMIT;

-- ----------------------------
-- Table structure for orangTua
-- ----------------------------
DROP TABLE IF EXISTS `orangTua`;
CREATE TABLE `orangTua` (
  `idOrangTua` int(11) NOT NULL AUTO_INCREMENT,
  `ayah` varchar(40) DEFAULT NULL,
  `pekerjaanAyah` varchar(15) DEFAULT NULL,
  `agamaAyah` varchar(10) DEFAULT NULL,
  `ibu` varchar(40) DEFAULT NULL,
  `pekerjaanIbu` varchar(15) DEFAULT NULL,
  `agamaIbu` varchar(10) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `noTelp` varchar(15) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `waliKelas` int(11) DEFAULT NULL,
  `anak` varchar(10) DEFAULT NULL,
  `idUser` int(11) DEFAULT NULL,
  PRIMARY KEY (`idOrangTua`),
  KEY `waliKelas` (`waliKelas`),
  KEY `anak` (`anak`),
  KEY `idUser` (`idUser`),
  CONSTRAINT `orangtua_ibfk_1` FOREIGN KEY (`waliKelas`) REFERENCES `akun` (`idUser`),
  CONSTRAINT `orangtua_ibfk_2` FOREIGN KEY (`anak`) REFERENCES `siswa` (`nisn`),
  CONSTRAINT `orangtua_ibfk_3` FOREIGN KEY (`idUser`) REFERENCES `akun` (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of orangTua
-- ----------------------------
BEGIN;
INSERT INTO `orangTua` (`idOrangTua`, `ayah`, `pekerjaanAyah`, `agamaAyah`, `ibu`, `pekerjaanIbu`, `agamaIbu`, `alamat`, `noTelp`, `dateCreated`, `dateModified`, `waliKelas`, `anak`, `idUser`) VALUES (1, 'Sukamto', 'TNI-AD', 'Islam', 'Sukarti', 'Ibu Rumah Tangg', 'Islam', 'Jl. Mawar No.22, Batu, Jawa Timur', '081553174200', 1673261275, 1673261275, 2, '1301202164', 5);
INSERT INTO `orangTua` (`idOrangTua`, `ayah`, `pekerjaanAyah`, `agamaAyah`, `ibu`, `pekerjaanIbu`, `agamaIbu`, `alamat`, `noTelp`, `dateCreated`, `dateModified`, `waliKelas`, `anak`, `idUser`) VALUES (2, 'Sukamto', 'TNI-AD', 'Islam', 'Sukarti', 'Ibu Rumah Tangg', 'Islam', 'Jl. Mawar No.22, Batu, Jawa Timur', '081553174200', 1673267042, 1673267042, 2, '1301202165', 7);
COMMIT;

-- ----------------------------
-- Table structure for rekomendasi
-- ----------------------------
DROP TABLE IF EXISTS `rekomendasi`;
CREATE TABLE `rekomendasi` (
  `idRekomendasi` int(11) NOT NULL AUTO_INCREMENT,
  `learningProfile` text DEFAULT NULL,
  `peminatan` text DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `idDokumen` int(11) DEFAULT NULL,
  `siswa` int(11) DEFAULT NULL,
  `guru` int(11) DEFAULT NULL,
  PRIMARY KEY (`idRekomendasi`),
  KEY `idDokumen` (`idDokumen`),
  CONSTRAINT `rekomendasi_ibfk_1` FOREIGN KEY (`idDokumen`) REFERENCES `dokumen` (`idDokumen`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of rekomendasi
-- ----------------------------
BEGIN;
INSERT INTO `rekomendasi` (`idRekomendasi`, `learningProfile`, `peminatan`, `dateCreated`, `idDokumen`, `siswa`, `guru`) VALUES (1, 'Teliti. Tekun. Detil. Rasional. Terstruktur. Independen. Senang berhitung. Senang menganalisis. Senang bekerja sendiri. Senang melakukan riset. Senang memecahkan masalah', 'Teknik', 1673272269, 1, 1301202164, 2);
INSERT INTO `rekomendasi` (`idRekomendasi`, `learningProfile`, `peminatan`, `dateCreated`, `idDokumen`, `siswa`, `guru`) VALUES (2, 'Kemampuan berpikir kritis dan analitis. Kemampuan mengekspresikan perasaan melalui seni. Kemampuan mengorganisir kegiatan seni rupa. Kemampuan menyajikan karya seni. Kemampuan bekerja secara individu dan tim. Kreatif dan Artistik', 'Seni', 1673273585, 2, 1301202165, 2);
COMMIT;

-- ----------------------------
-- Table structure for riwayatLogin
-- ----------------------------
DROP TABLE IF EXISTS `riwayatLogin`;
CREATE TABLE `riwayatLogin` (
  `idRiwayat` int(11) NOT NULL AUTO_INCREMENT,
  `ipAddress` varchar(17) DEFAULT NULL,
  `browser` varchar(150) DEFAULT NULL,
  `sisOperasi` varchar(50) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  PRIMARY KEY (`idRiwayat`),
  KEY `authorId` (`authorId`),
  CONSTRAINT `riwayatlogin_ibfk_1` FOREIGN KEY (`authorId`) REFERENCES `akun` (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of riwayatLogin
-- ----------------------------
BEGIN;
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (1, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673260922, 1);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (2, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673261238, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (3, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673261491, 4);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (4, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673261517, 5);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (5, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673261551, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (6, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673261855, 1);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (7, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673262286, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (8, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673267024, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (9, '172.20.10.3', 'Chrome 108.0.0.0', 'Windows 10', 1673268187, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (10, '172.20.10.3', 'Chrome 108.0.0.0', 'Windows 10', 1673268798, 4);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (11, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673268901, 4);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (12, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673268982, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (13, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673269227, 4);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (14, '172.20.10.3', 'Chrome 108.0.0.0', 'Windows 10', 1673269460, 1);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (15, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673269670, 6);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (16, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673269977, 5);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (17, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673270453, 7);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (18, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673270471, 6);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (19, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673271901, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (20, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673272319, 4);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (21, '172.20.10.3', 'Chrome 108.0.0.0', 'Windows 10', 1673273529, 2);
INSERT INTO `riwayatLogin` (`idRiwayat`, `ipAddress`, `browser`, `sisOperasi`, `dateCreated`, `authorId`) VALUES (22, '::1', 'Chrome 108.0.0.0', 'Mac OS X', 1673273549, 2);
COMMIT;

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `idRole` int(11) NOT NULL AUTO_INCREMENT,
  `namaRole` varchar(10) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  PRIMARY KEY (`idRole`),
  KEY `authorId` (`authorId`),
  CONSTRAINT `role_ibfk_1` FOREIGN KEY (`authorId`) REFERENCES `akun` (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of role
-- ----------------------------
BEGIN;
INSERT INTO `role` (`idRole`, `namaRole`, `dateCreated`, `dateModified`, `authorId`) VALUES (1, 'Admin', 1622049141, 1622049141, 1);
INSERT INTO `role` (`idRole`, `namaRole`, `dateCreated`, `dateModified`, `authorId`) VALUES (2, 'Guru', 1622049141, 1622049141, 1);
INSERT INTO `role` (`idRole`, `namaRole`, `dateCreated`, `dateModified`, `authorId`) VALUES (3, 'Orang Tua', 1622049141, 1622049141, 1);
INSERT INTO `role` (`idRole`, `namaRole`, `dateCreated`, `dateModified`, `authorId`) VALUES (4, 'Siswa', 1622049141, 1672107465, 1);
COMMIT;

-- ----------------------------
-- Table structure for siswa
-- ----------------------------
DROP TABLE IF EXISTS `siswa`;
CREATE TABLE `siswa` (
  `nisn` varchar(10) NOT NULL,
  `foto` varchar(128) DEFAULT NULL,
  `jenisKelamin` varchar(6) DEFAULT NULL,
  `agama` varchar(10) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `tanggalLahir` date DEFAULT NULL,
  `tempatLahir` varchar(15) DEFAULT NULL,
  `nama` varchar(40) DEFAULT NULL,
  `dateCreated` int(11) DEFAULT NULL,
  `dateModified` int(11) DEFAULT NULL,
  `waliKelas` int(11) DEFAULT NULL,
  `idKelas` int(11) DEFAULT NULL,
  `idUser` int(11) DEFAULT NULL,
  PRIMARY KEY (`nisn`),
  KEY `waliKelas` (`waliKelas`),
  KEY `idKelas` (`idKelas`),
  KEY `idUser` (`idUser`),
  CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`waliKelas`) REFERENCES `akun` (`idUser`),
  CONSTRAINT `siswa_ibfk_2` FOREIGN KEY (`idKelas`) REFERENCES `kelas` (`idKelas`),
  CONSTRAINT `siswa_ibfk_3` FOREIGN KEY (`idUser`) REFERENCES `akun` (`idUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of siswa
-- ----------------------------
BEGIN;
INSERT INTO `siswa` (`nisn`, `foto`, `jenisKelamin`, `agama`, `alamat`, `tanggalLahir`, `tempatLahir`, `nama`, `dateCreated`, `dateModified`, `waliKelas`, `idKelas`, `idUser`) VALUES ('1301202164', 'c4e77da0370802214bf5864a622756b2.jpg', 'Pria', 'Islam', 'Jl. Mawar No.22, Batu, Jawa Timur', '0000-00-00', 'Malang', 'Mohamad Irfan Nafiyanto', 1673261275, 1673268952, 2, 1, 4);
INSERT INTO `siswa` (`nisn`, `foto`, `jenisKelamin`, `agama`, `alamat`, `tanggalLahir`, `tempatLahir`, `nama`, `dateCreated`, `dateModified`, `waliKelas`, `idKelas`, `idUser`) VALUES ('1301202165', '', 'Wanita', 'Islam', 'Jl. Mawar No.22, Batu, Jawa Timur', '0000-00-00', 'Malang', 'Anwar Zaki Rusdiyanto', 1673267042, 1673267042, 2, 1, 6);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
